import { n as __toESM } from "./_runtime.mjs";
import { c as require_react, i as useQuery, s as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { s as useAuth, t as authHeaders } from "./_ssr/auth-store-BpIJ5qlL.mjs";
import { a as listAudit } from "./_ssr/admin.functions-Dzedo9E8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin.admin.audit-BR6FIamC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuditPage() {
	const { token } = useAuth();
	const { data, isLoading } = useQuery({
		queryKey: ["admin", "audit"],
		queryFn: () => listAudit({ headers: authHeaders() }),
		enabled: Boolean(token),
		retry: false
	});
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [search, setSearch] = (0, import_react.useState)("");
	const rows = Array.isArray(data) ? data : [];
	const visibleRows = (0, import_react.useMemo)(() => rows.filter((r) => {
		const matchesAction = filter === "all" || r.action === filter;
		const haystack = `${r.user_cnic ?? ""} ${r.entity_type} ${r.action} ${JSON.stringify(r.details ?? {})}`.toLowerCase();
		return matchesAction && haystack.includes(search.toLowerCase());
	}), [
		rows,
		filter,
		search
	]);
	const actions = [...new Set(rows.map((r) => r.action))];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl text-ink",
			children: "Audit log"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-ink-soft",
			children: "Latest 200 actions."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "manuscript p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-[0.22em] text-gold",
						children: "Events captured"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl text-ink",
						children: rows.length
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "manuscript p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-[0.22em] text-gold",
						children: "Creates"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl text-ink",
						children: rows.filter((r) => r.action === "create").length
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "manuscript p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-[0.22em] text-gold",
						children: "Updates"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl text-ink",
						children: rows.filter((r) => r.action === "update").length
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex flex-wrap gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: search,
					onChange: (e) => setSearch(e.target.value),
					placeholder: "Search audit trail…",
					className: "rounded-md border border-border bg-card px-3 py-2 text-sm text-ink"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: filter,
					onChange: (e) => setFilter(e.target.value),
					className: "rounded-md border border-border bg-card px-3 py-2 text-sm text-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "all",
						children: "All actions"
					}), actions.map((action) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: action,
						children: action
					}, action))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "self-center text-xs text-ink-soft",
					children: [visibleRows.length, " events shown"]
				})
			]
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-ink-soft",
			children: "Loading…"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 overflow-x-auto rounded-md border border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "bg-secondary text-left text-xs uppercase tracking-wider text-ink-soft",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2",
							children: "When"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2",
							children: "User"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2",
							children: "Action"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2",
							children: "Entity"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2",
							children: "Details"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: visibleRows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2 font-mono text-xs text-ink-soft",
							children: new Date(r.created_at).toLocaleString()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2 font-mono text-xs",
							children: r.user_cnic ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2 uppercase tracking-wider text-gold",
							children: r.action
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2",
							children: r.entity_type
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2 text-xs text-ink-soft",
							children: r.details ? JSON.stringify(r.details) : ""
						})
					]
				}, r.id)) })]
			})
		})
	] });
}
//#endregion
export { AuditPage as component };
