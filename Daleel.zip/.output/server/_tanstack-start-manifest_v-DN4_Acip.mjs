//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DN4_Acip.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Daleel/src/routes/__root.tsx",
		children: [
			"/",
			"/_admin",
			"/about",
			"/login",
			"/majalis",
			"/search",
			"/unauthorized",
			"/hadith/$id",
			"/majlis/$id"
		],
		preloads: [
			"/assets/index-vOZ25L2N.js",
			"/assets/jsx-runtime-DGeXAQPT.js",
			"/assets/QueryClientProvider-lfxkrpOA.js",
			"/assets/link-CQ8mVV7D.js",
			"/assets/matchContext-DAMHwyzy.js",
			"/assets/useRouter-pVD1wXl8.js",
			"/assets/invariant-DByYf4Yy.js",
			"/assets/redirect-DCb_aIiF.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-vOZ25L2N.js"
		} }]
	},
	"/": {
		filePath: "D:/Daleel/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-ByqkR6Wa.js", "/assets/useSuspenseQuery-bkgT6tHS.js"]
	},
	"/_admin": {
		filePath: "D:/Daleel/src/routes/_admin.tsx",
		children: ["/_admin/admin"],
		preloads: [
			"/assets/_admin-BRHHXcgW.js",
			"/assets/book-open-BsWmZ7d6.js",
			"/assets/users-B7Zn4g0I.js"
		]
	},
	"/about": {
		filePath: "D:/Daleel/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-Be9bpJOO.js"]
	},
	"/login": {
		filePath: "D:/Daleel/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-BpvAz9Ka.js", "/assets/createServerFn-DMeXjG8L.js"]
	},
	"/majalis": {
		filePath: "D:/Daleel/src/routes/majalis.tsx",
		children: void 0,
		preloads: ["/assets/majalis-Q1tYxcrt.js", "/assets/useSuspenseQuery-bkgT6tHS.js"]
	},
	"/search": {
		filePath: "D:/Daleel/src/routes/search.tsx",
		children: void 0,
		preloads: ["/assets/search-DQK3RxwS.js", "/assets/useQuery-6hDF10C2.js"]
	},
	"/unauthorized": {
		filePath: "D:/Daleel/src/routes/unauthorized.tsx",
		children: void 0,
		preloads: ["/assets/unauthorized-XbaZf1CR.js"]
	},
	"/_admin/admin": {
		filePath: "D:/Daleel/src/routes/_admin.admin.tsx",
		children: [
			"/_admin/admin/audit",
			"/_admin/admin/majalis",
			"/_admin/admin/users"
		],
		preloads: [
			"/assets/_admin.admin-CrTZyPto.js",
			"/assets/useQuery-6hDF10C2.js",
			"/assets/refresh-cw-B7adTU2j.js",
			"/assets/admin.functions-ra8udpeH.js"
		]
	},
	"/hadith/$id": {
		filePath: "D:/Daleel/src/routes/hadith.$id.tsx",
		children: void 0,
		preloads: ["/assets/hadith._id-B9yEBJi-.js", "/assets/useSuspenseQuery-bkgT6tHS.js"]
	},
	"/majlis/$id": {
		filePath: "D:/Daleel/src/routes/majlis.$id.tsx",
		children: void 0,
		preloads: ["/assets/majlis._id-CuHBPAPC.js", "/assets/useSuspenseQuery-bkgT6tHS.js"]
	},
	"/_admin/admin/audit": {
		filePath: "D:/Daleel/src/routes/_admin.admin.audit.tsx",
		children: void 0,
		preloads: ["/assets/_admin.admin.audit-Ve74vxxS.js"]
	},
	"/_admin/admin/majalis": {
		filePath: "D:/Daleel/src/routes/_admin.admin.majalis.tsx",
		children: ["/_admin/admin/majalis/$id/edit"],
		preloads: [
			"/assets/_admin.admin.majalis-OQgh0SQG.js",
			"/assets/trash-2-Bu_YZz85.js",
			"/assets/pen-line-mrKqZWUs.js"
		]
	},
	"/_admin/admin/users": {
		filePath: "D:/Daleel/src/routes/_admin.admin.users.tsx",
		children: void 0,
		preloads: ["/assets/_admin.admin.users-DXx656RY.js", "/assets/trash-2-Bu_YZz85.js"]
	},
	"/_admin/admin/majalis/$id/edit": {
		filePath: "D:/Daleel/src/routes/_admin.admin.majalis.$id.edit.tsx",
		children: void 0,
		preloads: ["/assets/_admin.admin.majalis._id.edit-BYuvMsE8.js"]
	}
} });
//#endregion
export { tsrStartManifest };
