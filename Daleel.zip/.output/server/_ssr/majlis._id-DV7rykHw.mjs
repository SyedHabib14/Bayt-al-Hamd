import { r as useSuspenseQuery, s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as majlisDetailQuery, o as useRealtimeInvalidate, t as formatDate } from "./public-data-ZCIUHGBc.mjs";
import { t as Route } from "./majlis._id-B2QNV_e7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/majlis._id-DV7rykHw.js
var import_jsx_runtime = require_jsx_runtime();
function MajlisView() {
	useRealtimeInvalidate();
	const { id } = Route.useParams();
	const { data } = useSuspenseQuery(majlisDetailQuery(id));
	if (!data) return null;
	const { majlis, hadiths, refs } = data;
	const refsByHadith = /* @__PURE__ */ new Map();
	refs.forEach((r) => {
		const arr = refsByHadith.get(r.hadith_id) ?? [];
		arr.push(r);
		refsByHadith.set(r.hadith_id, arr);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-4xl px-6 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/majalis",
				className: "text-xs uppercase tracking-[0.25em] text-ink-soft hover:text-ink",
				children: "← All majalis"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.35em] text-gold",
						children: formatDate(majlis.date)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl leading-tight text-ink sm:text-5xl",
						children: majlis.title
					}),
					majlis.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-2xl text-lg text-ink-soft",
						children: majlis.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-8" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 space-y-10",
				children: [hadiths.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "manuscript p-8 sm:p-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs uppercase tracking-[0.3em] text-gold",
								children: ["Ḥadīth ", i + 1]
							}), h.grade && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-ink-soft",
								children: h.grade
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "arabic-text mt-6",
							dir: "rtl",
							children: h.arabic_text
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule my-6" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-serif text-xl leading-relaxed text-ink",
							children: h.translation_en
						}),
						h.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 border-l-2 border-gold pl-4 text-sm italic text-ink-soft",
							children: h.notes
						}),
						(refsByHadith.get(h.id)?.length ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.25em] text-ink-soft",
								children: "References"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 space-y-1 text-sm text-ink",
								children: refsByHadith.get(h.id).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-serif italic",
										children: r.book_name
									}),
									r.volume && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [", vol. ", r.volume] }),
									r.page && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [", p. ", r.page] }),
									r.hadith_number && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [" · #", r.hadith_number] }),
									r.reliability_note && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-ink-soft",
										children: [" — ", r.reliability_note]
									})
								] }, r.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/hadith/$id",
								params: { id: h.id },
								className: "text-xs uppercase tracking-[0.25em] text-gold hover:underline",
								children: "Permalink →"
							})
						})
					]
				}, h.id)), hadiths.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-ink-soft",
					children: "No hadiths have been published for this majlis yet."
				})]
			})
		]
	});
}
//#endregion
export { MajlisView as component };
