import { n as __toESM } from "../_runtime.mjs";
import { a as QueryClientProvider, c as require_react, s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as clearAuth, s as useAuth } from "./auth-store-BpIJ5qlL.mjs";
import { _ as useRouter, c as HeadContent, d as Outlet, f as lazyRouteComponent, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Sun, l as Moon, t as X, u as Menu } from "../_libs/lucide-react.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { r as majalisQuery } from "./public-data-ZCIUHGBc.mjs";
import { t as Route$12 } from "../_admin.admin.majalis._id.edit-BX_j_NjR.mjs";
import { t as Route$13 } from "./hadith._id-CcbG15H7.mjs";
import { t as Route$14 } from "./majlis._id-B2QNV_e7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DVHJhYKW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-COlDqkv3.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	window.__lovableReportRuntimeError?.({
		message,
		stack: error instanceof Error ? error.stack : void 0,
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "manuscript max-w-md text-center px-10 py-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.3em] text-gold",
					children: "Dalīl"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-display text-6xl text-ink",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule my-6" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-ink-soft",
					children: "This page could not be found in the archive."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-8 inline-block border-b border-gold pb-1 text-ink hover:text-gold",
					children: "Return to the entrance"
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "manuscript max-w-md text-center px-10 py-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl text-ink",
					children: "A page could not be rendered"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule my-6" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-ink-soft",
					children: "The scribe was interrupted. Please try again."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "rounded-md bg-ink px-4 py-2 text-sm text-parchment hover:bg-ink-soft",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "rounded-md border border-ink/20 px-4 py-2 text-sm text-ink hover:bg-secondary",
						children: "Home"
					})]
				})
			]
		})
	});
}
var Route$11 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Dalīl — Verify every ḥadīth of the majlis" },
			{
				name: "description",
				content: "A scholarly archive to authenticate every ḥadīth quoted in a majlis, with the original Arabic, translation, references and grading."
			},
			{
				name: "author",
				content: "Dalīl"
			},
			{
				property: "og:title",
				content: "Dalīl — Verify every ḥadīth of the majlis"
			},
			{
				property: "og:description",
				content: "The original Arabic, translation, references and scholarly notes for every ḥadīth of each majlis."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "preload",
				href: "https://fonts.googleapis.com/css2?family=Amiri:wght@400;500;600;700&family=Cormorant+Garamond:wght@400;500;600;700&family=Inter:wght@400;500;600&family=Noto+Naskh+Arabic:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&family=Scheherazade+New:wght@400;500;600;700&display=swap",
				as: "style"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Amiri:wght@400;500;600;700&family=Cormorant+Garamond:wght@400;500;600;700&family=Inter:wght@400;500;600&family=Noto+Naskh+Arabic:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&family=Scheherazade+New:wght@400;500;600;700&display=swap"
			},
			{
				rel: "prefetch",
				href: "/majalis"
			},
			{
				rel: "prefetch",
				href: "/search"
			},
			{
				rel: "prefetch",
				href: "/about"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function SiteHeader() {
	const { user } = useAuth();
	const [dark, setDark] = (0, import_react.useState)(false);
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const saved = localStorage.getItem("dalil.theme");
		const enabled = saved === "dark" || !saved && window.matchMedia("(prefers-color-scheme: dark)").matches;
		setDark(enabled);
		document.documentElement.classList.toggle("dark", enabled);
	}, []);
	function toggleTheme() {
		const next = !dark;
		setDark(next);
		localStorage.setItem("dalil.theme", next ? "dark" : "light");
		document.documentElement.classList.toggle("dark", next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-30 border-b border-border/60 bg-parchment/85 backdrop-blur",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6 sm:py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "group flex items-baseline gap-3",
					onClick: () => setMobileOpen(false),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xl text-ink tracking-tight sm:text-2xl",
						children: "Dalīl"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline text-[11px] uppercase tracking-[0.3em] text-gold",
						children: "دَلِيل"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden items-center gap-6 text-sm font-medium text-ink-soft sm:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/majalis",
							className: "hover:text-ink",
							activeProps: { className: "text-ink" },
							children: "Majalis"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/search",
							className: "hover:text-ink",
							activeProps: { className: "text-ink" },
							children: "Search"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/about",
							className: "hover:text-ink",
							activeProps: { className: "text-ink" },
							children: "About"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: toggleTheme,
							"aria-label": dark ? "Switch to light mode" : "Switch to dark mode",
							className: "group relative flex h-8 w-14 items-center rounded-full border border-gold/50 bg-secondary p-1 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-gold",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `flex h-6 w-6 items-center justify-center rounded-full bg-gold text-accent-foreground shadow-sm transition-transform duration-300 ease-out ${dark ? "translate-x-6" : "translate-x-0"}`,
								children: dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { size: 14 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { size: 14 })
							})
						}),
						user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/admin",
								className: "rounded-md bg-ink px-3 py-1.5 text-xs text-parchment hover:bg-ink-soft",
								children: "Admin"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									clearAuth();
									window.location.href = "/";
								},
								className: "text-xs text-ink-soft hover:text-destructive",
								children: "Sign out"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "rounded-md border border-ink/20 px-3 py-1.5 text-xs text-ink hover:border-gold hover:text-gold",
							children: "Sign in"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 sm:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: toggleTheme,
						className: "flex h-9 w-9 items-center justify-center rounded-md border border-border text-ink-soft",
						children: dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { size: 16 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { size: 16 })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setMobileOpen(!mobileOpen),
						className: "flex h-9 w-9 items-center justify-center rounded-md border border-border text-ink",
						"aria-label": mobileOpen ? "Close menu" : "Open menu",
						children: mobileOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 18 })
					})]
				})
			]
		}), mobileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border/60 px-4 py-4 sm:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/majalis",
						className: "rounded-md px-4 py-3 text-sm font-medium text-ink-soft hover:bg-secondary",
						onClick: () => setMobileOpen(false),
						children: "Majalis"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/search",
						className: "rounded-md px-4 py-3 text-sm font-medium text-ink-soft hover:bg-secondary",
						onClick: () => setMobileOpen(false),
						children: "Search"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/about",
						className: "rounded-md px-4 py-3 text-sm font-medium text-ink-soft hover:bg-secondary",
						onClick: () => setMobileOpen(false),
						children: "About"
					}),
					user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin",
						className: "rounded-md bg-ink px-4 py-3 text-center text-sm font-medium text-parchment",
						onClick: () => setMobileOpen(false),
						children: "Admin"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							clearAuth();
							window.location.href = "/";
						},
						className: "rounded-md px-4 py-3 text-sm font-medium text-destructive hover:bg-destructive/10",
						children: "Sign out"
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: "rounded-md border border-ink/20 px-4 py-3 text-center text-sm font-medium text-ink",
						onClick: () => setMobileOpen(false),
						children: "Sign in"
					})
				]
			})
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "mt-24 border-t border-border/60 bg-parchment/70",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-6 py-10 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg text-ink",
					children: "Dalīl · دَلِيل"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mx-auto my-4 w-24" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-ink-soft",
					children: "A scholarly companion for verifying every ḥadīth of the majlis."
				})
			]
		})
	});
}
function RootComponent() {
	const { queryClient } = Route$11.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-screen flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
			]
		})
	});
}
var $$splitComponentImporter$10 = () => import("./unauthorized-BrCbfRTu.mjs");
var Route$10 = createFileRoute("/unauthorized")({
	head: () => ({ meta: [{ title: "Unauthorized — Dalīl" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./search-Dl1kngyN.mjs");
var Route$9 = createFileRoute("/search")({
	head: () => ({ meta: [{ title: "Search — Dalīl" }, {
		name: "description",
		content: "Search hadiths and majalis."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./majalis-B8A1i-uQ.mjs");
var Route$8 = createFileRoute("/majalis")({
	head: () => ({ meta: [{ title: "Majalis — Dalīl" }, {
		name: "description",
		content: "All published majalis with their date and hadiths."
	}] }),
	loader: ({ context }) => context.queryClient.ensureQueryData(majalisQuery),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./login-DEK7BtFU.mjs");
var Route$7 = createFileRoute("/login")({
	head: () => ({ meta: [{ title: "Sign in — Dalīl" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./about-Dh_kmm6F.mjs");
var Route$6 = createFileRoute("/about")({
	head: () => ({ meta: [{ title: "About — Dalīl" }, {
		name: "description",
		content: "About the Dalīl archive."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("../_admin-BAYTWBNj.mjs");
var Route$5 = createFileRoute("/_admin")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./routes-DkNDpVpi.mjs");
var Route$4 = createFileRoute("/")({
	head: () => ({ meta: [{ title: "Dalīl — Every ḥadīth of the majlis, verified" }, {
		name: "description",
		content: "Browse majalis and read the authentic Arabic, translation, references and grading for every ḥadīth quoted."
	}] }),
	loader: ({ context }) => context.queryClient.ensureQueryData(majalisQuery),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("../_admin.admin-Dx7DPXgW.mjs");
var Route$3 = createFileRoute("/_admin/admin")({
	head: () => ({ meta: [{ title: "Admin — Dalīl" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("../_admin.admin.users-suY19We8.mjs");
var Route$2 = createFileRoute("/_admin/admin/users")({
	head: () => ({ meta: [{ title: "Users · Admin — Dalīl" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("../_admin.admin.majalis-DQZsDy2l.mjs");
var Route$1 = createFileRoute("/_admin/admin/majalis")({
	head: () => ({ meta: [{ title: "Majalis · Admin — Dalīl" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("../_admin.admin.audit-BR6FIamC.mjs");
var Route = createFileRoute("/_admin/admin/audit")({
	head: () => ({ meta: [{ title: "Audit · Admin — Dalīl" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var UnauthorizedRoute = Route$10.update({
	id: "/unauthorized",
	path: "/unauthorized",
	getParentRoute: () => Route$11
});
var SearchRoute = Route$9.update({
	id: "/search",
	path: "/search",
	getParentRoute: () => Route$11
});
var MajalisRoute = Route$8.update({
	id: "/majalis",
	path: "/majalis",
	getParentRoute: () => Route$11
});
var LoginRoute = Route$7.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$11
});
var AboutRoute = Route$6.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$11
});
var AdminRoute = Route$5.update({
	id: "/_admin",
	getParentRoute: () => Route$11
});
var IndexRoute = Route$4.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$11
});
var MajlisIdRoute = Route$14.update({
	id: "/majlis/$id",
	path: "/majlis/$id",
	getParentRoute: () => Route$11
});
var HadithIdRoute = Route$13.update({
	id: "/hadith/$id",
	path: "/hadith/$id",
	getParentRoute: () => Route$11
});
var AdminAdminRoute = Route$3.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => AdminRoute
});
var AdminAdminUsersRoute = Route$2.update({
	id: "/users",
	path: "/users",
	getParentRoute: () => AdminAdminRoute
});
var AdminAdminMajalisRoute = Route$1.update({
	id: "/majalis",
	path: "/majalis",
	getParentRoute: () => AdminAdminRoute
});
var AdminAdminAuditRoute = Route.update({
	id: "/audit",
	path: "/audit",
	getParentRoute: () => AdminAdminRoute
});
var AdminAdminMajalisRouteChildren = { AdminAdminMajalisIdEditRoute: Route$12.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => AdminAdminMajalisRoute
}) };
var AdminAdminRouteChildren = {
	AdminAdminAuditRoute,
	AdminAdminMajalisRoute: AdminAdminMajalisRoute._addFileChildren(AdminAdminMajalisRouteChildren),
	AdminAdminUsersRoute
};
var AdminRouteChildren = { AdminAdminRoute: AdminAdminRoute._addFileChildren(AdminAdminRouteChildren) };
var rootRouteChildren = {
	IndexRoute,
	AdminRoute: AdminRoute._addFileChildren(AdminRouteChildren),
	AboutRoute,
	LoginRoute,
	MajalisRoute,
	SearchRoute,
	UnauthorizedRoute,
	HadithIdRoute,
	MajlisIdRoute
};
var routeTree = Route$11._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
