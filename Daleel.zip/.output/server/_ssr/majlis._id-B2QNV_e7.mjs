import { M as notFound, f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as majlisDetailQuery, t as formatDate } from "./public-data-ZCIUHGBc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/majlis._id-B2QNV_e7.js
var $$splitComponentImporter = () => import("./majlis._id-DV7rykHw.mjs");
var Route = createFileRoute("/majlis/$id")({
	loader: async ({ context, params }) => {
		const data = await context.queryClient.ensureQueryData(majlisDetailQuery(params.id));
		if (!data) throw notFound();
		return data;
	},
	head: ({ loaderData }) => ({ meta: loaderData ? [{ title: `${loaderData.majlis.title} — Dalīl` }, {
		name: "description",
		content: loaderData.majlis.description ?? `Majlis on ${formatDate(loaderData.majlis.date)}`
	}] : [{ title: "Majlis — Dalīl" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
