import { i as TSS_SERVER_FUNCTION } from "./esm-B50dUWcE.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-Do2E56bH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/createSsrRpc-DZN23mmR.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
//#endregion
export { createSsrRpc as t };
