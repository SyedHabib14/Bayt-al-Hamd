import { n as __toESM } from "../_runtime.mjs";
import { c as require_react, n as queryOptions, o as useQueryClient } from "../_libs/react+tanstack__react-query.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import process from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/public-data-ZCIUHGBc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function isNewSupabaseApiKey(value) {
	return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}
function createSupabaseFetch(supabaseKey) {
	return (input, init) => {
		const headers = new Headers(typeof Request !== "undefined" && input instanceof Request ? input.headers : void 0);
		if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
		if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) headers.delete("Authorization");
		headers.set("apikey", supabaseKey);
		return fetch(input, {
			...init,
			headers
		});
	};
}
function createSupabaseClient() {
	const SUPABASE_URL = process.env.SUPABASE_URL || "https://nulhrafwmfywbmjyhovi.supabase.co";
	const SUPABASE_PUBLISHABLE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im51bGhyYWZ3bWZ5d2Jtanlob3ZpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ5Njk3NjAsImV4cCI6MjEwMDU0NTc2MH0.IdDAoRiFdOw5l0HqVSmNiK59r4EG1TZW-zws35hww3Q";
	if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) {
		const message = `Missing Supabase environment variable(s): ${[...!SUPABASE_URL ? ["SUPABASE_URL"] : [], ...!SUPABASE_PUBLISHABLE_KEY ? ["SUPABASE_PUBLISHABLE_KEY"] : []].join(", ")}. Connect Supabase in Lovable Cloud.`;
		console.error(`[Supabase] ${message}`);
		throw new Error(message);
	}
	return createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
		global: { fetch: createSupabaseFetch(SUPABASE_PUBLISHABLE_KEY) },
		auth: {
			storage: typeof window !== "undefined" ? localStorage : void 0,
			persistSession: true,
			autoRefreshToken: true
		}
	});
}
var _supabase;
var supabase = new Proxy({}, { get(_, prop, receiver) {
	if (!_supabase) _supabase = createSupabaseClient();
	return Reflect.get(_supabase, prop, receiver);
} });
var majalisQuery = queryOptions({
	queryKey: ["public", "majalis"],
	queryFn: async () => {
		const { data, error } = await supabase.from("majalis").select("id, title, date, description").order("date", { ascending: false });
		if (error) throw error;
		return data ?? [];
	}
});
var majlisDetailQuery = (id) => queryOptions({
	queryKey: [
		"public",
		"majlis",
		id
	],
	queryFn: async () => {
		const { data, error } = await supabase.from("majalis").select("id, title, date, description").eq("id", id).maybeSingle();
		if (error) throw error;
		if (!data) return null;
		const { data: hadiths } = await supabase.from("hadiths").select("id, arabic_text, translation_en, grade, notes, position").eq("majlis_id", id).order("position", { ascending: true }).order("created_at", { ascending: true });
		const ids = (hadiths ?? []).map((h) => h.id);
		const refs = ids.length ? (await supabase.from("hadith_references").select("*").in("hadith_id", ids)).data ?? [] : [];
		return {
			majlis: data,
			hadiths: hadiths ?? [],
			refs
		};
	}
});
var hadithDetailQuery = (id) => queryOptions({
	queryKey: [
		"public",
		"hadith",
		id
	],
	queryFn: async () => {
		const { data: hadith, error } = await supabase.from("hadiths").select("id, majlis_id, arabic_text, translation_en, grade, notes").eq("id", id).maybeSingle();
		if (error) throw error;
		if (!hadith) return null;
		const [{ data: majlis }, { data: refs }] = await Promise.all([supabase.from("majalis").select("id, title, date").eq("id", hadith.majlis_id).maybeSingle(), supabase.from("hadith_references").select("*").eq("hadith_id", hadith.id)]);
		return {
			hadith,
			majlis,
			refs: refs ?? []
		};
	}
});
function useRealtimeInvalidate() {
	const qc = useQueryClient();
	(0, import_react.useEffect)(() => {
		let mounted = true;
		const ch = supabase.channel("public-changes").on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "majalis"
		}, (payload) => {
			if (!mounted) return;
			console.debug("[realtime] majalis change:", payload.eventType, payload.new);
			qc.invalidateQueries({ queryKey: ["public"] });
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "hadiths"
		}, (payload) => {
			if (!mounted) return;
			console.debug("[realtime] hadiths change:", payload.eventType, payload.new);
			qc.invalidateQueries({ queryKey: ["public"] });
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "hadith_references"
		}, (payload) => {
			if (!mounted) return;
			console.debug("[realtime] hadith_references change:", payload.eventType, payload.new);
			qc.invalidateQueries({ queryKey: ["public"] });
		}).subscribe((status) => {
			console.debug("[realtime] subscription status:", status);
		});
		return () => {
			mounted = false;
			supabase.removeChannel(ch);
		};
	}, [qc]);
}
function formatDate(iso) {
	return (/* @__PURE__ */ new Date(iso + (iso.length === 10 ? "T00:00:00" : ""))).toLocaleDateString("en-GB", {
		day: "numeric",
		month: "long",
		year: "numeric"
	});
}
//#endregion
export { supabase as a, majlisDetailQuery as i, hadithDetailQuery as n, useRealtimeInvalidate as o, majalisQuery as r, formatDate as t };
