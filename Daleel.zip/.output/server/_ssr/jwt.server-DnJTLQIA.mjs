import process from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/jwt.server-DnJTLQIA.js
var enc = new TextEncoder();
function b64url(buf) {
	const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
	let bin = "";
	for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
	return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function b64urlDecode(s) {
	s = s.replace(/-/g, "+").replace(/_/g, "/");
	while (s.length % 4) s += "=";
	const bin = atob(s);
	const out = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
	return out;
}
async function key(secret) {
	return crypto.subtle.importKey("raw", enc.encode(secret), {
		name: "HMAC",
		hash: "SHA-256"
	}, false, ["sign", "verify"]);
}
function jwtSecret() {
	return process.env.DALIL_JWT_SECRET || process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
}
async function signJwt(payload, ttlSeconds = 3600 * 2) {
	const secret = jwtSecret();
	if (!secret) throw new Error("JWT secret not configured");
	const now = Math.floor(Date.now() / 1e3);
	const full = {
		...payload,
		iat: now,
		exp: now + ttlSeconds
	};
	const data = `${b64url(enc.encode(JSON.stringify({
		alg: "HS256",
		typ: "JWT"
	})))}.${b64url(enc.encode(JSON.stringify(full)))}`;
	const k = await key(secret);
	return `${data}.${b64url(await crypto.subtle.sign("HMAC", k, enc.encode(data)))}`;
}
async function verifyJwt(token) {
	try {
		const secret = jwtSecret();
		if (!secret) return null;
		const [h, p, s] = token.split(".");
		if (!h || !p || !s) return null;
		const k = await key(secret);
		const sigBytes = b64urlDecode(s);
		if (!await crypto.subtle.verify("HMAC", k, sigBytes, enc.encode(`${h}.${p}`))) return null;
		const payload = JSON.parse(new TextDecoder().decode(b64urlDecode(p)));
		if (payload.exp < Math.floor(Date.now() / 1e3)) return null;
		return payload;
	} catch {
		return null;
	}
}
//#endregion
export { verifyJwt as n, signJwt as t };
