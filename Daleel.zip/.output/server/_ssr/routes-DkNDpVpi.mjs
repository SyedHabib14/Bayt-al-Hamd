import { r as useSuspenseQuery, s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as useRealtimeInvalidate, r as majalisQuery, t as formatDate } from "./public-data-ZCIUHGBc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DkNDpVpi.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	useRealtimeInvalidate();
	const { data: majalis } = useSuspenseQuery(majalisQuery);
	const recent = majalis.slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-6 pt-16 pb-20 sm:pt-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.35em] text-gold",
				children: "A scholarly archive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-4 max-w-3xl font-display text-5xl leading-[1.05] text-ink sm:text-6xl",
				children: ["Every ḥadīth of the majlis, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
					className: "font-serif italic text-ink-soft",
					children: "verified."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 max-w-2xl text-lg text-ink-soft",
				children: "Dalīl is a companion for readers, students and scholars. For each majlis we publish the original Arabic with full tashkeel, a reliable English translation, the primary references and short scholarly notes — so no ḥadīth passes unchecked."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/majalis",
					className: "rounded-md bg-ink px-5 py-2.5 text-sm font-medium text-parchment hover:bg-ink-soft",
					children: "Browse majalis"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/about",
					className: "text-sm text-ink-soft underline decoration-gold underline-offset-4 hover:text-ink",
					children: "What is Dalīl?"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-14 max-w-md" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 font-arabic text-3xl leading-loose text-ink",
				dir: "rtl",
				children: "إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ"
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-6 pb-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-8 flex items-end justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl text-ink",
				children: "Recent majalis"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/majalis",
				className: "text-sm text-ink-soft hover:text-ink",
				children: "View all →"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 sm:grid-cols-2",
			children: [recent.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/majlis/$id",
				params: { id: m.id },
				className: "manuscript block p-8 transition hover:-translate-y-0.5 hover:shadow-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.25em] text-gold",
						children: formatDate(m.date)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-3 font-display text-2xl text-ink",
						children: m.title
					}),
					m.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-ink-soft line-clamp-3",
						children: m.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-6 w-16" })
				]
			}, m.id)), recent.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-ink-soft",
				children: "No majalis have been published yet."
			})]
		})]
	})] });
}
//#endregion
export { Home as component };
