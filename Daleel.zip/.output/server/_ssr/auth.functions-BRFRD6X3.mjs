import { c as createServerFn } from "./esm-B50dUWcE.mjs";
import { t as getRequestHeader } from "./request-response-B5fXtxnG.mjs";
import { n as verifyJwt, t as signJwt } from "./jwt.server-DnJTLQIA.mjs";
import { a as stringType, i as objectType } from "../_libs/zod.mjs";
import { n as getAdminClient, t as createServerRpc } from "./supabase-admin.server-BlNAYmf1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.functions-BRFRD6X3.js
var CNIC_RE = /^\d{13}$/;
var cnicSchema = objectType({ cnic: stringType().transform((s) => s.replace(/[-\s]/g, "")).refine((s) => CNIC_RE.test(s), { message: "CNIC must be 13 digits" }) });
var cnicLogin_createServerFn_handler = createServerRpc({
	id: "69e62a9721b82b06404632a5a9e5fb2e385740eac52b2ee8658b95fe03ee414f",
	name: "cnicLogin",
	filename: "src/lib/auth.functions.ts"
}, (opts) => cnicLogin.__executeServer(opts));
var cnicLogin = createServerFn({ method: "POST" }).inputValidator((d) => cnicSchema.parse(d)).handler(cnicLogin_createServerFn_handler, async ({ data }) => {
	const supabase = getAdminClient();
	const ip = getRequestHeader("cf-connecting-ip") || getRequestHeader("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
	const since = (/* @__PURE__ */ new Date(Date.now() - 900 * 1e3)).toISOString();
	const { count, error: attemptsError } = await supabase.from("cnic_login_attempts").select("id", {
		count: "exact",
		head: true
	}).eq("ip", ip).gte("attempted_at", since);
	if (attemptsError) throw new Error("Authentication service is not configured correctly.");
	if ((count ?? 0) >= 10) throw new Response("Too many attempts. Please wait a few minutes.", { status: 429 });
	const { data: user, error: userError } = await supabase.from("users").select("id, cnic, full_name, role, is_active").eq("cnic", data.cnic).maybeSingle();
	if (userError) throw new Error("Authentication service is not configured correctly.");
	const success = !!(user && user.is_active);
	await supabase.from("cnic_login_attempts").insert({
		cnic: data.cnic,
		ip,
		success
	});
	if (!success || !user) throw new Response("Not authorized.", { status: 401 });
	const token = await signJwt({
		sub: user.id,
		cnic: user.cnic,
		role: user.role,
		name: user.full_name
	});
	const { error: auditError } = await supabase.from("audit_log").insert({
		user_id: user.id,
		user_cnic: user.cnic,
		action: "login",
		entity_type: "auth",
		details: { ip },
		ip
	});
	if (auditError) console.error("[auth] audit log insert failed", auditError);
	return {
		token,
		user: {
			id: user.id,
			name: user.full_name,
			role: user.role,
			cnic: user.cnic
		}
	};
});
var getMe_createServerFn_handler = createServerRpc({
	id: "05d540c91ea9147d57c434f81d698c2e3ff5d23ba136ebab060a4513339a2b8c",
	name: "getMe",
	filename: "src/lib/auth.functions.ts"
}, (opts) => getMe.__executeServer(opts));
var getMe = createServerFn({ method: "POST" }).inputValidator((d) => d).handler(getMe_createServerFn_handler, async ({ data }) => {
	const payload = await verifyJwt(data.token);
	if (!payload) return null;
	return {
		id: payload.sub,
		name: payload.name,
		role: payload.role,
		cnic: payload.cnic,
		exp: payload.exp
	};
});
//#endregion
export { cnicLogin_createServerFn_handler, getMe_createServerFn_handler };
