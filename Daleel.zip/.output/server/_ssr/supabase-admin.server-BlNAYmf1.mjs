import { i as TSS_SERVER_FUNCTION } from "./esm-B50dUWcE.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import process from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/supabase-admin.server-BlNAYmf1.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function getAdminClient() {
	const url = process.env.SUPABASE_URL;
	const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
	if (!url || !key) throw new Error("Supabase server env not configured");
	return createClient(url, key, { auth: {
		persistSession: false,
		autoRefreshToken: false
	} });
}
//#endregion
export { getAdminClient as n, createServerRpc as t };
