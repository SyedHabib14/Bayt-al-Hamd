import { M as notFound, f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as hadithDetailQuery } from "./public-data-ZCIUHGBc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hadith._id-CcbG15H7.js
var $$splitComponentImporter = () => import("./hadith._id-BRoNrLwI.mjs");
var Route = createFileRoute("/hadith/$id")({
	loader: async ({ context, params }) => {
		const data = await context.queryClient.ensureQueryData(hadithDetailQuery(params.id));
		if (!data) throw notFound();
		return data;
	},
	head: ({ loaderData }) => ({ meta: loaderData ? [{ title: `Ḥadīth — ${loaderData.majlis?.title ?? "Dalīl"}` }] : [{ title: "Ḥadīth — Dalīl" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
