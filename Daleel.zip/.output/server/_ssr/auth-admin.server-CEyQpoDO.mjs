import { t as getRequestHeader } from "./request-response-B5fXtxnG.mjs";
import { n as createMiddleware } from "./createStart-DwZhSttb.mjs";
import { n as verifyJwt } from "./jwt.server-DnJTLQIA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-admin.server-CEyQpoDO.js
/**
* Middleware that authenticates admin/scholar/editor users.
*
* Checks both the Authorization header (set by TanStack Start's server function
* client-side fetcher) AND the `dalil.token` cookie (for SSR page transitions).
*
* The Authorization header takes priority; the cookie is the fallback.
* This ensures that both JS-powered navigation (client-side) and hard page loads
* (SSR) work with authentication.
*/
var requireAdminAuth = createMiddleware({ type: "function" }).server(async ({ next }) => {
	const authHeader = getRequestHeader("authorization") || getRequestHeader("Authorization");
	const cookie = getRequestHeader("cookie") ?? "";
	const cookieToken = cookie.match(/(?:^|;\s*)dalil\.token=([^;]+)/)?.[1];
	let token = "";
	if (authHeader?.startsWith("Bearer ")) token = authHeader.slice(7).trim();
	else if (cookieToken) token = decodeURIComponent(cookieToken);
	if (!token) {
		const hasCookie = cookie.length > 0;
		console.debug("[auth-middleware] No token found", {
			hasAuthHeader: !!authHeader,
			hasCookieHeader: hasCookie,
			hasDalilCookie: !!cookieToken,
			cookieLength: cookie.length
		});
		throw new Response("Unauthorized — no valid authentication token found. Please sign in again.", { status: 401 });
	}
	const payload = await verifyJwt(token);
	if (!payload) {
		console.debug("[auth-middleware] JWT verification failed — token invalid or expired");
		throw new Response("Unauthorized — your session has expired. Please sign in again.", { status: 401 });
	}
	if (![
		"admin",
		"scholar",
		"editor"
	].includes(payload.role)) {
		console.debug("[auth-middleware] Role forbidden", { role: payload.role });
		throw new Response("Forbidden — you do not have permission to perform this action.", { status: 403 });
	}
	return next({ context: { auth: payload } });
});
//#endregion
export { requireAdminAuth as t };
