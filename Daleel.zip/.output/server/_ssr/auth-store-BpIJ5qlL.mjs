import { n as __toESM } from "../_runtime.mjs";
import { c as require_react } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-store-BpIJ5qlL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var TOKEN_KEY = "dalil.token";
var USER_KEY = "dalil.user";
var listeners = /* @__PURE__ */ new Set();
function emit() {
	listeners.forEach((l) => l());
}
function getToken() {
	if (typeof window === "undefined") return null;
	return localStorage.getItem(TOKEN_KEY);
}
function getUser() {
	if (typeof window === "undefined") return null;
	const raw = localStorage.getItem(USER_KEY);
	if (!raw) return null;
	try {
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
/**
* Set auth state:
* 1. Store token + user in localStorage for client-side reads.
* 2. Set a cookie for SSR — the cookie is read by the requireAdminAuth middleware.
*    Important attributes: Path=/ so it's available on all routes,
*    SameSite=Lax (default) for CSRF protection, Secure only on HTTPS.
*/
function setAuth(token, user) {
	localStorage.setItem(TOKEN_KEY, token);
	localStorage.setItem(USER_KEY, JSON.stringify(user));
	const isSecure = typeof window !== "undefined" && window.location.protocol === "https:";
	const cookie = `${TOKEN_KEY}=${encodeURIComponent(token)}; Path=/; Max-Age=7200; SameSite=Lax${isSecure ? "; Secure" : ""}`;
	document.cookie = cookie;
	console.debug("[auth] setAuth: token and cookie set", {
		hasToken: !!token,
		cookiePresent: document.cookie.includes(TOKEN_KEY)
	});
	emit();
}
/**
* Clear auth state completely — localStorage + cookie expiry.
*/
function clearAuth() {
	localStorage.removeItem(TOKEN_KEY);
	localStorage.removeItem(USER_KEY);
	document.cookie = `${TOKEN_KEY}=; Path=/; Max-Age=0; SameSite=Lax`;
	document.cookie = `${TOKEN_KEY}=; Path=/admin; Max-Age=0; SameSite=Lax`;
	console.debug("[auth] clearAuth: token and cookie cleared");
	emit();
}
function useAuth() {
	const subscribe = (cb) => {
		listeners.add(cb);
		const onStorage = () => cb();
		window.addEventListener("storage", onStorage);
		return () => {
			listeners.delete(cb);
			window.removeEventListener("storage", onStorage);
		};
	};
	const getSnapshot = () => localStorage.getItem(TOKEN_KEY) ?? null;
	const token = (0, import_react.useSyncExternalStore)(subscribe, getSnapshot, () => null);
	return {
		token,
		user: token ? getUser() : null
	};
}
/**
* Build Authorization headers for TanStack Start server function calls.
* TanStack Start serializes these headers and sends them along with the request.
* The server checks both the Authorization header AND the cookie fallback.
*/
function authHeaders() {
	const t = getToken();
	return t ? { Authorization: `Bearer ${t}` } : {};
}
/**
* Check if a token is expired (client-side heuristic).
*/
function isTokenExpired(token) {
	try {
		const parts = token.split(".");
		if (parts.length !== 3) return true;
		const base64 = parts[1].replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(parts[1].length / 4) * 4, "=");
		const payload = JSON.parse(atob(base64));
		return payload.exp ? payload.exp * 1e3 < Date.now() : true;
	} catch {
		return true;
	}
}
//#endregion
export { isTokenExpired as a, getUser as i, clearAuth as n, setAuth as o, getToken as r, useAuth as s, authHeaders as t };
