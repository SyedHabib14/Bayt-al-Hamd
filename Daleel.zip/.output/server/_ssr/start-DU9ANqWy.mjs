import { n as createMiddleware, r as createStart, t as createCsrfMiddleware } from "./createStart-DwZhSttb.mjs";
import { t as renderErrorPage } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/start-DU9ANqWy.js
var attachDalilAuth = createMiddleware({ type: "function" }).client(async ({ next }) => {
	if (typeof window === "undefined") return next();
	const token = window.localStorage.getItem("dalil.token");
	if (!token) return next();
	return next({ headers: { Authorization: `Bearer ${token}` } });
});
var errorMiddleware = createMiddleware().server(async ({ next }) => {
	try {
		return await next();
	} catch (error) {
		if (error != null && typeof error === "object" && "statusCode" in error) throw error;
		console.error(error);
		return new Response(renderErrorPage(), {
			status: 500,
			headers: { "content-type": "text/html; charset=utf-8" }
		});
	}
});
var csrfMiddleware = createCsrfMiddleware({ filter: (ctx) => ctx.handlerType === "serverFn" });
var startInstance = createStart(() => ({
	functionMiddleware: [attachDalilAuth],
	requestMiddleware: [errorMiddleware, csrfMiddleware]
}));
//#endregion
export { startInstance };
