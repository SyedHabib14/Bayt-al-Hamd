import { n as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { o as setAuth, s as useAuth } from "./auth-store-BpIJ5qlL.mjs";
import { _ as useRouter, g as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as createServerFn } from "./esm-B50dUWcE.mjs";
import { t as createSsrRpc } from "./createSsrRpc-DZN23mmR.mjs";
import { a as stringType, i as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-DEK7BtFU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CNIC_RE = /^\d{13}$/;
var cnicSchema = objectType({ cnic: stringType().transform((s) => s.replace(/[-\s]/g, "")).refine((s) => CNIC_RE.test(s), { message: "CNIC must be 13 digits" }) });
var cnicLogin = createServerFn({ method: "POST" }).inputValidator((d) => cnicSchema.parse(d)).handler(createSsrRpc("69e62a9721b82b06404632a5a9e5fb2e385740eac52b2ee8658b95fe03ee414f"));
createServerFn({ method: "POST" }).inputValidator((d) => d).handler(createSsrRpc("05d540c91ea9147d57c434f81d698c2e3ff5d23ba136ebab060a4513339a2b8c"));
function LoginPage() {
	const { user } = useAuth();
	const navigate = useNavigate();
	const router = useRouter();
	const [cnic, setCnic] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (user) navigate({
			to: "/admin",
			replace: true
		});
	}, [user, navigate]);
	function formatCnic(value) {
		const digits = value.replace(/\D/g, "").slice(0, 13);
		return [
			digits.slice(0, 5),
			digits.slice(5, 12),
			digits.slice(12)
		].filter(Boolean).join("-");
	}
	if (user) return null;
	async function onSubmit(e) {
		e.preventDefault();
		setBusy(true);
		setError(null);
		try {
			const digits = cnic.replace(/[-\s]/g, "");
			if (!/^\d{13}$/.test(digits)) {
				setError("CNIC must be 13 digits.");
				setBusy(false);
				return;
			}
			const res = await cnicLogin({ data: { cnic: digits } });
			setAuth(res.token, res.user);
			router.invalidate();
			navigate({ to: "/admin" });
		} catch (err) {
			const msg = err && typeof err === "object" && "message" in err && err.message ? err.message : "Not authorized.";
			setError(msg.includes("Too many") || msg.includes("not configured") || msg.includes("JWT") ? msg : "Not authorized.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto flex min-h-[70vh] max-w-md items-center px-4 py-12 sm:px-6 sm:py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "manuscript w-full p-6 sm:p-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] uppercase tracking-[0.3em] text-gold sm:text-xs",
					children: "Scholar access"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-2xl text-ink sm:text-3xl",
					children: "Sign in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule my-5 sm:my-6" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-ink-soft",
					children: "Enter your enrolled 13-digit CNIC. Access is limited to authorised editors."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "mt-6 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mb-1.5 block text-[10px] uppercase tracking-[0.2em] text-ink-soft sm:text-xs",
							children: "CNIC"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							inputMode: "numeric",
							autoComplete: "off",
							spellCheck: false,
							value: cnic,
							onChange: (e) => setCnic(formatCnic(e.target.value)),
							placeholder: "XXXXX-XXXXXXX-X",
							className: "w-full rounded-md border border-border bg-card px-4 py-3 font-mono text-base tracking-wide text-ink focus:border-gold focus:outline-none sm:text-lg"
						})] }),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: busy,
							className: "w-full rounded-md bg-ink py-3 text-sm font-medium text-parchment hover:bg-ink-soft disabled:opacity-60 transition-colors duration-200",
							children: busy ? "Verifying…" : "Enter"
						})
					]
				})
			]
		})
	});
}
//#endregion
export { LoginPage as component };
