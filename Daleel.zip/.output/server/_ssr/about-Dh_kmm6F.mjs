import { s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-Dh_kmm6F.js
var import_jsx_runtime = require_jsx_runtime();
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-6 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.35em] text-gold",
				children: "About"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl text-ink",
				children: "What is Dalīl?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-6 w-24" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "prose mt-8 space-y-5 font-serif text-lg leading-relaxed text-ink",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Dalīl" }),
						" (دَلِيل — ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "the evidence, the guide" }),
						") is a scholarly archive dedicated to a single, careful task: to record and verify every ḥadīth quoted during a majlis."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "For each gathering we publish the original Arabic text with full tashkeel, a reliable English translation, the primary references from the canonical collections, and short scholarly notes on grading and context. The intent is to allow anyone — student, teacher or curious reader — to follow the majlis and confirm the source of every narration." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Editorial work is undertaken by an enrolled circle of scholars and editors. Only they may add, edit or publish content, and every change is written into a permanent audit log." })
				]
			})
		]
	});
}
//#endregion
export { About as component };
