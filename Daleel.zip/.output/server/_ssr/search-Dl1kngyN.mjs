import { n as __toESM } from "../_runtime.mjs";
import { c as require_react, i as useQuery, s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as supabase, t as formatDate } from "./public-data-ZCIUHGBc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-Dl1kngyN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useDebounce(value, delay) {
	const [debouncedValue, setDebouncedValue] = (0, import_react.useState)(value);
	(0, import_react.useEffect)(() => {
		const timer = setTimeout(() => setDebouncedValue(value), delay);
		return () => clearTimeout(timer);
	}, [value, delay]);
	return debouncedValue;
}
function SearchPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const debouncedQ = useDebounce(q, 300);
	const inputRef = (0, import_react.useRef)(null);
	const { data, isFetching } = useQuery({
		queryKey: ["search", debouncedQ],
		enabled: debouncedQ.trim().length >= 2,
		queryFn: async () => {
			const term = `%${debouncedQ.trim()}%`;
			const [h, m] = await Promise.all([supabase.from("hadiths").select("id, translation_en, arabic_text, majlis_id, majalis!inner(title,date)").or(`translation_en.ilike.${term},arabic_normalized.ilike.${term}`).limit(30), supabase.from("majalis").select("id, title, date, description").or(`title.ilike.${term},description.ilike.${term}`).limit(20)]);
			return {
				hadiths: h.data ?? [],
				majalis: m.data ?? []
			};
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl px-4 py-12 sm:px-6 sm:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl text-ink sm:text-4xl",
				children: "Search the archive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-4 w-24" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-6 sm:mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: inputRef,
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search hadiths, majalis, keywords…",
					className: "w-full rounded-md border border-border bg-card px-4 py-3 pr-10 text-base text-ink focus:border-gold focus:outline-none sm:text-lg",
					autoFocus: true
				}), isFetching && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute right-3 top-1/2 -translate-y-1/2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-4 animate-spin rounded-full border-2 border-gold border-t-transparent" })
				})]
			}),
			debouncedQ.trim().length < 2 && debouncedQ.trim().length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-ink-soft",
				children: "Enter at least 2 characters."
			}),
			debouncedQ.trim().length < 2 && debouncedQ.trim().length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-ink-soft",
				children: "Enter at least 2 characters to search."
			}),
			data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-8 sm:mt-10 sm:space-y-10",
				children: [
					data.majalis.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg text-ink sm:text-xl",
						children: "Majalis"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 divide-y divide-border rounded-md border border-border bg-card",
						children: data.majalis.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "px-4 py-3 sm:px-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/majlis/$id",
								params: { id: m.id },
								className: "block hover:text-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase tracking-[0.25em] text-gold sm:text-xs",
									children: formatDate(m.date)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-0 mt-0.5 block font-display text-base text-ink sm:ml-3 sm:inline sm:text-lg",
									children: m.title
								})]
							})
						}, m.id))
					})] }),
					data.hadiths.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg text-ink sm:text-xl",
						children: "Ḥadīths"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-3 sm:space-y-4",
						children: data.hadiths.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "manuscript p-4 sm:p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "arabic-text text-xl sm:text-2xl",
									dir: "rtl",
									children: h.arabic_text
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-serif text-sm text-ink sm:text-base",
									children: h.translation_en
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/hadith/$id",
									params: { id: h.id },
									className: "mt-2 inline-block text-[10px] uppercase tracking-[0.25em] text-gold sm:mt-3 sm:text-xs",
									children: "Open →"
								})
							]
						}, h.id))
					})] }),
					data.majalis.length === 0 && data.hadiths.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "manuscript flex flex-col items-center py-12 text-center sm:py-16",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-ink-soft",
							children: [
								"No results found for \"",
								debouncedQ,
								"\""
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-ink-soft/60",
							children: "Try different keywords or check your spelling."
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { SearchPage as component };
