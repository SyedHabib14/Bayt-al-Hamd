import { r as useSuspenseQuery, s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as useRealtimeInvalidate, r as majalisQuery, t as formatDate } from "./public-data-ZCIUHGBc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/majalis-B8A1i-uQ.js
var import_jsx_runtime = require_jsx_runtime();
function MajalisList() {
	useRealtimeInvalidate();
	const { data } = useSuspenseQuery(majalisQuery);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl px-6 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.35em] text-gold",
				children: "The archive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl text-ink",
				children: "Majalis"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-6 w-24" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-12 divide-y divide-border",
				children: [data.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "group py-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/majlis/$id",
						params: { id: m.id },
						className: "flex flex-col gap-2 sm:flex-row sm:items-baseline sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.25em] text-gold",
								children: formatDate(m.date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 font-display text-2xl text-ink group-hover:text-gold",
								children: m.title
							}),
							m.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-2xl text-sm text-ink-soft",
								children: m.description
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-ink-soft group-hover:text-ink",
							children: "Read →"
						})]
					})
				}, m.id)), data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "py-10 text-ink-soft",
					children: "No majalis published yet."
				})]
			})
		]
	});
}
//#endregion
export { MajalisList as component };
