import { c as createServerFn } from "./esm-B50dUWcE.mjs";
import { t as requireAdminAuth } from "./auth-admin.server-CEyQpoDO.mjs";
import { t as createSsrRpc } from "./createSsrRpc-DZN23mmR.mjs";
import { a as stringType, i as objectType, n as enumType, r as numberType, t as booleanType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-Dzedo9E8.js
var majlisInput = objectType({
	id: stringType().uuid().optional(),
	title: stringType().min(2).max(200),
	date: stringType().min(4),
	description: stringType().max(2e3).optional().nullable(),
	is_published: booleanType().default(false)
});
var saveMajlis = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).inputValidator((d) => majlisInput.parse(d)).handler(createSsrRpc("5b6d230cc4ea5a65305d7883a9d0a6556ae3b1bc3520f360a1818b9afd664c2b"));
var deleteMajlis = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).inputValidator((d) => d).handler(createSsrRpc("3a8bae3c72e4f893820ac177661b264ef551c78824220d25750c61a3846c23a4"));
var listAllMajalis = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).handler(createSsrRpc("cb91472390c339938b6d914f78a2a03f08ba031eb095e347f0e02989df17f92d"));
var hadithInput = objectType({
	id: stringType().uuid().optional(),
	majlis_id: stringType().uuid(),
	arabic_text: stringType().min(3),
	translation_en: stringType().min(3),
	grade: stringType().max(120).optional().nullable(),
	notes: stringType().max(4e3).optional().nullable(),
	is_published: booleanType().default(false),
	position: numberType().int().default(0)
});
var saveHadith = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).inputValidator((d) => hadithInput.parse(d)).handler(createSsrRpc("d98d7e711eaf1585d4bbf69ce68058336b47396a83bf772cee9225437b963990"));
var deleteHadith = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).inputValidator((d) => d).handler(createSsrRpc("8ef4422953076c399a279d00262b8cc4e31745f6aa9b4014b795c4ec91d47738"));
var userInput = objectType({
	id: stringType().uuid().optional(),
	cnic: stringType().regex(/^\d{13}$/),
	full_name: stringType().min(2).max(120),
	role: enumType([
		"admin",
		"scholar",
		"editor"
	]),
	is_active: booleanType().default(true)
});
var listUsers = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).handler(createSsrRpc("ae1d531e1714d053869d1e069815a71e199346ef621d80ab0f46be85080718ab"));
var saveUser = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).inputValidator((d) => userInput.parse(d)).handler(createSsrRpc("e80a7ac87c9a302fc9a7840d3333e8cff0e60218c059c3681396154d351abd97"));
var deleteUser = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).inputValidator((d) => d).handler(createSsrRpc("5f15d9c6194c3264109b1c81741c60a8654b66a5caffc1ee319315a3a983394e"));
var listAudit = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).handler(createSsrRpc("467f84d6d531fdce76f0581f425531ca1e810bf08231fdda18eb058ea8dfbac5"));
//#endregion
export { listAudit as a, saveMajlis as c, listAllMajalis as i, saveUser as l, deleteMajlis as n, listUsers as o, deleteUser as r, saveHadith as s, deleteHadith as t };
