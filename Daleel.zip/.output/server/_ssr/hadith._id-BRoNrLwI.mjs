import { r as useSuspenseQuery, s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as hadithDetailQuery, o as useRealtimeInvalidate, t as formatDate } from "./public-data-ZCIUHGBc.mjs";
import { t as Route } from "./hadith._id-CcbG15H7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hadith._id-BRoNrLwI.js
var import_jsx_runtime = require_jsx_runtime();
function HadithView() {
	useRealtimeInvalidate();
	const { id } = Route.useParams();
	const { data } = useSuspenseQuery(hadithDetailQuery(id));
	if (!data) return null;
	const { hadith, majlis, refs } = data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-6 py-16",
		children: [majlis && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/majlis/$id",
			params: { id: majlis.id },
			className: "text-xs uppercase tracking-[0.25em] text-ink-soft hover:text-ink",
			children: [
				"← ",
				majlis.title,
				" · ",
				formatDate(majlis.date)
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "manuscript mt-6 p-10 sm:p-14",
			children: [
				hadith.grade && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.3em] text-gold",
					children: hadith.grade
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "arabic-text mt-6",
					dir: "rtl",
					children: hadith.arabic_text
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule my-8" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-serif text-2xl leading-relaxed text-ink",
					children: hadith.translation_en
				}),
				hadith.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 border-l-2 border-gold pl-4 text-sm italic text-ink-soft",
					children: hadith.notes
				}),
				refs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.25em] text-ink-soft",
						children: "References"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-1 text-sm text-ink",
						children: refs.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-serif italic",
								children: r.book_name
							}),
							r.volume && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [", vol. ", r.volume] }),
							r.page && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [", p. ", r.page] }),
							r.hadith_number && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [" · #", r.hadith_number] }),
							r.reliability_note && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-ink-soft",
								children: [" — ", r.reliability_note]
							})
						] }, r.id))
					})]
				})
			]
		})]
	});
}
//#endregion
export { HadithView as component };
