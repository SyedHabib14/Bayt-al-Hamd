import { c as createServerFn } from "./esm-B50dUWcE.mjs";
import { t as requireAdminAuth } from "./auth-admin.server-CEyQpoDO.mjs";
import { a as stringType, i as objectType, n as enumType, r as numberType, t as booleanType } from "../_libs/zod.mjs";
import { n as getAdminClient, t as createServerRpc } from "./supabase-admin.server-BlNAYmf1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-Dr09NrVd.js
var majlisInput = objectType({
	id: stringType().uuid().optional(),
	title: stringType().min(2).max(200),
	date: stringType().min(4),
	description: stringType().max(2e3).optional().nullable(),
	is_published: booleanType().default(false)
});
var saveMajlis_createServerFn_handler = createServerRpc({
	id: "5b6d230cc4ea5a65305d7883a9d0a6556ae3b1bc3520f360a1818b9afd664c2b",
	name: "saveMajlis",
	filename: "src/lib/admin.functions.ts"
}, (opts) => saveMajlis.__executeServer(opts));
var saveMajlis = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).inputValidator((d) => majlisInput.parse(d)).handler(saveMajlis_createServerFn_handler, async ({ data, context }) => {
	const supabase = getAdminClient();
	const auth = context.auth;
	if (data.id) {
		const { data: row, error } = await supabase.from("majalis").update({
			title: data.title,
			date: data.date,
			description: data.description ?? null,
			is_published: data.is_published,
			updated_by: auth.sub
		}).eq("id", data.id).select().single();
		if (error) throw new Response(error.message, { status: 400 });
		await supabase.from("audit_log").insert({
			user_id: auth.sub,
			user_cnic: auth.cnic,
			action: "update",
			entity_type: "majlis",
			entity_id: row.id,
			details: { title: row.title }
		});
		return row;
	}
	const { data: row, error } = await supabase.from("majalis").insert({
		title: data.title,
		date: data.date,
		description: data.description ?? null,
		is_published: data.is_published,
		created_by: auth.sub,
		updated_by: auth.sub
	}).select().single();
	if (error) throw new Response(error.message, { status: 400 });
	await supabase.from("audit_log").insert({
		user_id: auth.sub,
		user_cnic: auth.cnic,
		action: "create",
		entity_type: "majlis",
		entity_id: row.id,
		details: { title: row.title }
	});
	return row;
});
var deleteMajlis_createServerFn_handler = createServerRpc({
	id: "3a8bae3c72e4f893820ac177661b264ef551c78824220d25750c61a3846c23a4",
	name: "deleteMajlis",
	filename: "src/lib/admin.functions.ts"
}, (opts) => deleteMajlis.__executeServer(opts));
var deleteMajlis = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).inputValidator((d) => d).handler(deleteMajlis_createServerFn_handler, async ({ data, context }) => {
	const supabase = getAdminClient();
	const { error } = await supabase.from("majalis").delete().eq("id", data.id);
	if (error) throw new Response(error.message, { status: 400 });
	await supabase.from("audit_log").insert({
		user_id: context.auth.sub,
		user_cnic: context.auth.cnic,
		action: "delete",
		entity_type: "majlis",
		entity_id: data.id
	});
	return { ok: true };
});
var listAllMajalis_createServerFn_handler = createServerRpc({
	id: "cb91472390c339938b6d914f78a2a03f08ba031eb095e347f0e02989df17f92d",
	name: "listAllMajalis",
	filename: "src/lib/admin.functions.ts"
}, (opts) => listAllMajalis.__executeServer(opts));
var listAllMajalis = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).handler(listAllMajalis_createServerFn_handler, async () => {
	const { data, error } = await getAdminClient().from("majalis").select("*").order("date", { ascending: false });
	if (error) throw new Response(error.message, { status: 500 });
	return data;
});
var hadithInput = objectType({
	id: stringType().uuid().optional(),
	majlis_id: stringType().uuid(),
	arabic_text: stringType().min(3),
	translation_en: stringType().min(3),
	grade: stringType().max(120).optional().nullable(),
	notes: stringType().max(4e3).optional().nullable(),
	is_published: booleanType().default(false),
	position: numberType().int().default(0)
});
function normalizeArabic(s) {
	return s.normalize("NFC").replace(/[\u064B-\u0652\u0670\u0640]/g, "").replace(/\s+/g, " ").trim();
}
var saveHadith_createServerFn_handler = createServerRpc({
	id: "d98d7e711eaf1585d4bbf69ce68058336b47396a83bf772cee9225437b963990",
	name: "saveHadith",
	filename: "src/lib/admin.functions.ts"
}, (opts) => saveHadith.__executeServer(opts));
var saveHadith = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).inputValidator((d) => hadithInput.parse(d)).handler(saveHadith_createServerFn_handler, async ({ data, context }) => {
	const supabase = getAdminClient();
	const auth = context.auth;
	const payload = {
		majlis_id: data.majlis_id,
		arabic_text: data.arabic_text,
		arabic_normalized: normalizeArabic(data.arabic_text),
		translation_en: data.translation_en,
		grade: data.grade ?? null,
		notes: data.notes ?? null,
		is_published: data.is_published,
		position: data.position,
		updated_by: auth.sub
	};
	if (data.id) {
		const { data: row, error } = await supabase.from("hadiths").update(payload).eq("id", data.id).select().single();
		if (error) throw new Response(error.message, { status: 400 });
		await supabase.from("audit_log").insert({
			user_id: auth.sub,
			user_cnic: auth.cnic,
			action: "update",
			entity_type: "hadith",
			entity_id: row.id
		});
		return row;
	}
	const { data: row, error } = await supabase.from("hadiths").insert({
		...payload,
		created_by: auth.sub
	}).select().single();
	if (error) throw new Response(error.message, { status: 400 });
	await supabase.from("audit_log").insert({
		user_id: auth.sub,
		user_cnic: auth.cnic,
		action: "create",
		entity_type: "hadith",
		entity_id: row.id
	});
	return row;
});
var deleteHadith_createServerFn_handler = createServerRpc({
	id: "8ef4422953076c399a279d00262b8cc4e31745f6aa9b4014b795c4ec91d47738",
	name: "deleteHadith",
	filename: "src/lib/admin.functions.ts"
}, (opts) => deleteHadith.__executeServer(opts));
var deleteHadith = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).inputValidator((d) => d).handler(deleteHadith_createServerFn_handler, async ({ data, context }) => {
	const supabase = getAdminClient();
	const { error } = await supabase.from("hadiths").delete().eq("id", data.id);
	if (error) throw new Response(error.message, { status: 400 });
	await supabase.from("audit_log").insert({
		user_id: context.auth.sub,
		user_cnic: context.auth.cnic,
		action: "delete",
		entity_type: "hadith",
		entity_id: data.id
	});
	return { ok: true };
});
var userInput = objectType({
	id: stringType().uuid().optional(),
	cnic: stringType().regex(/^\d{13}$/),
	full_name: stringType().min(2).max(120),
	role: enumType([
		"admin",
		"scholar",
		"editor"
	]),
	is_active: booleanType().default(true)
});
var listUsers_createServerFn_handler = createServerRpc({
	id: "ae1d531e1714d053869d1e069815a71e199346ef621d80ab0f46be85080718ab",
	name: "listUsers",
	filename: "src/lib/admin.functions.ts"
}, (opts) => listUsers.__executeServer(opts));
var listUsers = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).handler(listUsers_createServerFn_handler, async ({ context }) => {
	if (context.auth.role !== "admin") throw new Response("Forbidden", { status: 403 });
	const { data, error } = await getAdminClient().from("users").select("*").order("created_at", { ascending: false });
	if (error) throw new Response(error.message, { status: 500 });
	return data;
});
var saveUser_createServerFn_handler = createServerRpc({
	id: "e80a7ac87c9a302fc9a7840d3333e8cff0e60218c059c3681396154d351abd97",
	name: "saveUser",
	filename: "src/lib/admin.functions.ts"
}, (opts) => saveUser.__executeServer(opts));
var saveUser = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).inputValidator((d) => userInput.parse(d)).handler(saveUser_createServerFn_handler, async ({ data, context }) => {
	if (context.auth.role !== "admin") throw new Response("Forbidden", { status: 403 });
	const supabase = getAdminClient();
	if (data.id) {
		const { data: row, error } = await supabase.from("users").update({
			cnic: data.cnic,
			full_name: data.full_name,
			role: data.role,
			is_active: data.is_active
		}).eq("id", data.id).select().single();
		if (error) throw new Response(error.message, { status: 400 });
		await supabase.from("audit_log").insert({
			user_id: context.auth.sub,
			user_cnic: context.auth.cnic,
			action: "update",
			entity_type: "user",
			entity_id: row.id
		});
		return row;
	}
	const { data: row, error } = await supabase.from("users").insert({
		cnic: data.cnic,
		full_name: data.full_name,
		role: data.role,
		is_active: data.is_active
	}).select().single();
	if (error) throw new Response(error.message, { status: 400 });
	await supabase.from("audit_log").insert({
		user_id: context.auth.sub,
		user_cnic: context.auth.cnic,
		action: "create",
		entity_type: "user",
		entity_id: row.id
	});
	return row;
});
var deleteUser_createServerFn_handler = createServerRpc({
	id: "5f15d9c6194c3264109b1c81741c60a8654b66a5caffc1ee319315a3a983394e",
	name: "deleteUser",
	filename: "src/lib/admin.functions.ts"
}, (opts) => deleteUser.__executeServer(opts));
var deleteUser = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).inputValidator((d) => d).handler(deleteUser_createServerFn_handler, async ({ data, context }) => {
	if (context.auth.role !== "admin") throw new Response("Forbidden", { status: 403 });
	if (data.id === context.auth.sub) throw new Response("Cannot remove yourself.", { status: 400 });
	const supabase = getAdminClient();
	const { error } = await supabase.from("users").delete().eq("id", data.id);
	if (error) throw new Response(error.message, { status: 400 });
	await supabase.from("audit_log").insert({
		user_id: context.auth.sub,
		user_cnic: context.auth.cnic,
		action: "delete",
		entity_type: "user",
		entity_id: data.id
	});
	return { ok: true };
});
var listAudit_createServerFn_handler = createServerRpc({
	id: "467f84d6d531fdce76f0581f425531ca1e810bf08231fdda18eb058ea8dfbac5",
	name: "listAudit",
	filename: "src/lib/admin.functions.ts"
}, (opts) => listAudit.__executeServer(opts));
var listAudit = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).handler(listAudit_createServerFn_handler, async () => {
	const { data, error } = await getAdminClient().from("audit_log").select("*").order("created_at", { ascending: false }).limit(200);
	if (error) throw new Response(error.message, { status: 500 });
	return data;
});
//#endregion
export { deleteHadith_createServerFn_handler, deleteMajlis_createServerFn_handler, deleteUser_createServerFn_handler, listAllMajalis_createServerFn_handler, listAudit_createServerFn_handler, listUsers_createServerFn_handler, saveHadith_createServerFn_handler, saveMajlis_createServerFn_handler, saveUser_createServerFn_handler };
