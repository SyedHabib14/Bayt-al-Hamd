import { f as lazyRouteComponent, p as createFileRoute } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin.admin.majalis._id.edit-BX_j_NjR.js
var $$splitComponentImporter = () => import("./_admin.admin.majalis._id.edit-B6m5KCK1.mjs");
var Route = createFileRoute("/_admin/admin/majalis/$id/edit")({
	head: () => ({ meta: [{ title: "Edit majlis · Admin — Dalīl" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
