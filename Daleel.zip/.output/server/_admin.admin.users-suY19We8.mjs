import { n as __toESM } from "./_runtime.mjs";
import { c as require_react, i as useQuery, o as useQueryClient, s as require_jsx_runtime, t as useMutation } from "./_libs/react+tanstack__react-query.mjs";
import { s as useAuth, t as authHeaders } from "./_ssr/auth-store-BpIJ5qlL.mjs";
import { n as Users, r as Trash2, s as Plus } from "./_libs/lucide-react.mjs";
import { l as saveUser, o as listUsers, r as deleteUser } from "./_ssr/admin.functions-Dzedo9E8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin.admin.users-suY19We8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UsersPage() {
	const { user } = useAuth();
	const qc = useQueryClient();
	const { data, isLoading, error } = useQuery({
		queryKey: ["admin", "users"],
		queryFn: () => listUsers({ headers: authHeaders() }),
		enabled: user?.role === "admin",
		retry: false,
		staleTime: 3e4
	});
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [search, setSearch] = (0, import_react.useState)("");
	const users = Array.isArray(data) ? data : [];
	const filteredUsers = (0, import_react.useMemo)(() => {
		const q = search.trim().toLowerCase();
		return q ? users.filter((u) => `${u.full_name} ${u.cnic} ${u.role}`.toLowerCase().includes(q)) : users;
	}, [search, users]);
	const active = users.filter((u) => u.is_active).length;
	const admins = users.filter((u) => u.role === "admin").length;
	const del = useMutation({
		mutationFn: (id) => deleteUser({
			data: { id },
			headers: authHeaders()
		}),
		onSuccess: () => qc.invalidateQueries({ queryKey: ["admin", "users"] })
	});
	if (user?.role !== "admin") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "manuscript p-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-ink-soft",
			children: "Only administrators may manage users."
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl text-ink sm:text-3xl",
				children: "Enrolled users"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => setAdding((v) => !v),
				className: "inline-flex items-center gap-1.5 rounded-md bg-ink px-4 py-2 text-sm text-parchment hover:bg-ink-soft",
				children: [adding ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 }), adding ? "Cancel" : "Enroll user"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-6 grid gap-3 sm:grid-cols-4",
			children: [
				[
					"Enrolled",
					users.length,
					"All authorised identities"
				],
				[
					"Active",
					active,
					"Can sign in now"
				],
				[
					"Administrators",
					admins,
					"Full editorial access"
				],
				[
					"Other roles",
					users.length - admins,
					"Scholars and editors"
				]
			].map(([label, value, hint]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "manuscript p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-[0.22em] text-gold",
						children: label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl text-ink",
						children: value
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[11px] text-ink-soft",
						children: hint
					})
				]
			}, label))
		}),
		users.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: search,
				onChange: (e) => setSearch(e.target.value),
				placeholder: "Search name, CNIC or role…",
				className: "w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-ink sm:max-w-sm"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "whitespace-nowrap text-xs text-ink-soft",
				children: [filteredUsers.length, " shown"]
			})]
		}),
		adding && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserForm, { onDone: () => {
			setAdding(false);
			qc.invalidateQueries({ queryKey: ["admin", "users"] });
		} }),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 space-y-4",
			children: [
				1,
				2,
				3
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "animate-pulse border-b border-border pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-40 rounded bg-ink-soft/20" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-1 h-3 w-28 rounded bg-ink-soft/20" })]
			}, i))
		}),
		error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "manuscript mt-4 border-destructive/30 p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: "Failed to load users. Please try refreshing."
			})
		}),
		!isLoading && !error && (data ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "manuscript mt-6 flex flex-col items-center py-12 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
					size: 36,
					className: "text-ink-soft/40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-display text-lg text-ink",
					children: "No users enrolled"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-ink-soft",
					children: "Enroll the first user to get started."
				})
			]
		}),
		!isLoading && filteredUsers.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 divide-y divide-border rounded-md border border-border bg-card",
			children: filteredUsers.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-col gap-3 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg text-ink",
							children: u.full_name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 font-mono text-xs text-ink-soft",
							children: u.cnic
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `mt-1 inline-block rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider ${u.is_active ? "bg-emerald-500/10 text-emerald-600" : "bg-amber-500/10 text-amber-600"}`,
							children: [u.role, !u.is_active && " · inactive"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => {
						if (confirm("Remove this user?")) del.mutate(u.id);
					},
					className: "inline-flex items-center gap-1.5 rounded-md border border-destructive/40 px-3 py-2 text-sm text-destructive hover:bg-destructive/10 sm:py-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 14 }), "Remove"]
				})]
			}, u.id))
		})
	] });
}
function UserForm({ onDone }) {
	const [cnic, setCnic] = (0, import_react.useState)("");
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("editor");
	const mut = useMutation({
		mutationFn: () => saveUser({
			headers: authHeaders(),
			data: {
				cnic: cnic.replace(/[-\s]/g, ""),
				full_name: fullName,
				role,
				is_active: true
			}
		}),
		onSuccess: onDone
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			mut.mutate();
		},
		className: "manuscript mt-4 space-y-4 p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs uppercase tracking-[0.2em] text-ink-soft",
						children: "CNIC"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: cnic,
						onChange: (e) => setCnic(e.target.value),
						required: true,
						placeholder: "13 digits",
						className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2 font-mono text-ink"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs uppercase tracking-[0.2em] text-ink-soft",
						children: "Full name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: fullName,
						onChange: (e) => setFullName(e.target.value),
						required: true,
						className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2 text-ink"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs uppercase tracking-[0.2em] text-ink-soft",
						children: "Role"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: role,
						onChange: (e) => setRole(e.target.value),
						className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2 text-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "admin",
								children: "admin"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "scholar",
								children: "scholar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "editor",
								children: "editor"
							})
						]
					})] })
				]
			}),
			mut.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: "Could not enroll — CNIC may already exist."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: mut.isPending,
				className: "rounded-md bg-ink px-4 py-2 text-sm text-parchment hover:bg-ink-soft",
				children: mut.isPending ? "Saving…" : "Enroll"
			})
		]
	});
}
//#endregion
export { UsersPage as component };
