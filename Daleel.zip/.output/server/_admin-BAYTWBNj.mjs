import { n as __toESM } from "./_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { a as isTokenExpired, i as getUser, n as clearAuth, r as getToken, s as useAuth } from "./_ssr/auth-store-BpIJ5qlL.mjs";
import { d as Outlet, g as useNavigate, h as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { a as ShieldAlert, d as LogOut, f as LayoutDashboard, h as BookOpen, n as Users, t as X, u as Menu } from "./_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin-BAYTWBNj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ADMIN_NAV = [
	{
		to: "/admin",
		label: "Dashboard",
		icon: LayoutDashboard
	},
	{
		to: "/admin/majalis",
		label: "Majalis",
		icon: BookOpen
	},
	{
		to: "/admin/users",
		label: "Users",
		icon: Users
	},
	{
		to: "/admin/audit",
		label: "Audit",
		icon: ShieldAlert
	}
];
function AdminLayout() {
	const { user, token } = useAuth();
	const navigate = useNavigate();
	const [checking, setChecking] = (0, import_react.useState)(true);
	const [mobileNavOpen, setMobileNavOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const currentToken = getToken();
		const storedUser = getUser();
		if (!currentToken || storedUser === null) {
			navigate({
				to: "/unauthorized",
				replace: true
			});
			return;
		}
		if (isTokenExpired(currentToken)) {
			console.debug("[admin] Token expired, clearing auth");
			clearAuth();
			navigate({
				to: "/unauthorized",
				replace: true
			});
			return;
		}
		setChecking(false);
	}, [
		token,
		user,
		navigate
	]);
	if (checking) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto flex min-h-[60vh] max-w-6xl items-center justify-center px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-8 w-8 animate-spin rounded-full border-2 border-gold border-t-transparent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-ink-soft",
				children: "Verifying access…"
			})]
		})
	});
	if (!getToken() || !user) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex flex-wrap items-center justify-between gap-4 border-b border-border pb-4 sm:pb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-[0.35em] text-gold sm:text-xs",
								children: "Editorial"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-1 font-display text-2xl text-ink sm:text-3xl",
								children: "Admin"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-ink-soft sm:text-sm",
								children: [
									"Signed in as ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-ink font-medium",
										children: user.name
									}),
									" ·",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "uppercase tracking-wider text-gold",
										children: user.role
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setMobileNavOpen(!mobileNavOpen),
						className: "flex h-10 w-10 items-center justify-center rounded-md border border-border sm:hidden",
						"aria-label": mobileNavOpen ? "Close navigation" : "Open navigation",
						children: mobileNavOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 18 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "hidden items-center gap-2 sm:flex",
						children: [ADMIN_NAV.map(({ to, label, icon: Icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to,
							activeOptions: { exact: true },
							activeProps: { className: "bg-ink text-parchment border-ink" },
							className: "flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-xs text-ink hover:border-gold hover:text-gold sm:text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								size: 14,
								className: "shrink-0"
							}), label]
						}, to)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								clearAuth();
								navigate({ to: "/" });
							},
							className: "flex items-center gap-1.5 rounded-md border border-destructive/40 px-3 py-1.5 text-xs text-destructive hover:bg-destructive/10 sm:text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { size: 14 }), "Sign out"]
						})]
					})
				]
			}),
			mobileNavOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-6 rounded-md border border-border bg-card p-4 sm:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "flex flex-col gap-2",
					children: [ADMIN_NAV.map(({ to, label, icon: Icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to,
						activeOptions: { exact: to === "/admin" },
						activeProps: { className: "bg-ink text-parchment border-ink" },
						className: "flex items-center gap-3 rounded-md border border-border px-4 py-3 text-sm text-ink hover:border-gold hover:text-gold",
						onClick: () => setMobileNavOpen(false),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							size: 16,
							className: "shrink-0"
						}), label]
					}, to)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							clearAuth();
							navigate({ to: "/" });
						},
						className: "flex items-center gap-3 rounded-md border border-destructive/40 px-4 py-3 text-sm text-destructive hover:bg-destructive/10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { size: 16 }), "Sign out"]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
		]
	});
}
//#endregion
export { AdminLayout as component };
