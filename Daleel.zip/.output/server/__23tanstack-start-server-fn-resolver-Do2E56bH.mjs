//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-Do2E56bH.js
var manifest = {
	"05d540c91ea9147d57c434f81d698c2e3ff5d23ba136ebab060a4513339a2b8c": {
		functionName: "getMe_createServerFn_handler",
		importer: () => import("./_ssr/auth.functions-BRFRD6X3.mjs")
	},
	"3a8bae3c72e4f893820ac177661b264ef551c78824220d25750c61a3846c23a4": {
		functionName: "deleteMajlis_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-Dr09NrVd.mjs")
	},
	"467f84d6d531fdce76f0581f425531ca1e810bf08231fdda18eb058ea8dfbac5": {
		functionName: "listAudit_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-Dr09NrVd.mjs")
	},
	"5b6d230cc4ea5a65305d7883a9d0a6556ae3b1bc3520f360a1818b9afd664c2b": {
		functionName: "saveMajlis_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-Dr09NrVd.mjs")
	},
	"5f15d9c6194c3264109b1c81741c60a8654b66a5caffc1ee319315a3a983394e": {
		functionName: "deleteUser_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-Dr09NrVd.mjs")
	},
	"69e62a9721b82b06404632a5a9e5fb2e385740eac52b2ee8658b95fe03ee414f": {
		functionName: "cnicLogin_createServerFn_handler",
		importer: () => import("./_ssr/auth.functions-BRFRD6X3.mjs")
	},
	"8ef4422953076c399a279d00262b8cc4e31745f6aa9b4014b795c4ec91d47738": {
		functionName: "deleteHadith_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-Dr09NrVd.mjs")
	},
	"ae1d531e1714d053869d1e069815a71e199346ef621d80ab0f46be85080718ab": {
		functionName: "listUsers_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-Dr09NrVd.mjs")
	},
	"cb91472390c339938b6d914f78a2a03f08ba031eb095e347f0e02989df17f92d": {
		functionName: "listAllMajalis_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-Dr09NrVd.mjs")
	},
	"d98d7e711eaf1585d4bbf69ce68058336b47396a83bf772cee9225437b963990": {
		functionName: "saveHadith_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-Dr09NrVd.mjs")
	},
	"e80a7ac87c9a302fc9a7840d3333e8cff0e60218c059c3681396154d351abd97": {
		functionName: "saveUser_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-Dr09NrVd.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
