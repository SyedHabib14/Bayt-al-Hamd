import { i as useQuery, o as useQueryClient, s as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { s as useAuth, t as authHeaders } from "./_ssr/auth-store-BpIJ5qlL.mjs";
import { h as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { h as BookOpen, m as EyeOff, o as RefreshCw, p as FileText } from "./_libs/lucide-react.mjs";
import { i as listAllMajalis } from "./_ssr/admin.functions-Dzedo9E8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin.admin-Dx7DPXgW.js
var import_jsx_runtime = require_jsx_runtime();
function StatCard({ icon: Icon, label, value, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "manuscript flex items-start gap-4 p-5 sm:p-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${accent ?? "bg-secondary"}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				size: 18,
				className: "text-ink"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] uppercase tracking-[0.3em] text-gold sm:text-xs",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-3xl text-ink sm:text-4xl",
				children: value
			})]
		})]
	});
}
function Dashboard() {
	const { token } = useAuth();
	const queryClient = useQueryClient();
	const { data: majalis, isError, isLoading, refetch } = useQuery({
		queryKey: ["admin", "majalis"],
		queryFn: () => listAllMajalis({ headers: authHeaders() }),
		enabled: Boolean(token),
		retry: false,
		staleTime: 3e4
	});
	const rows = Array.isArray(majalis) ? majalis : [];
	const total = rows.length;
	const published = rows.filter((m) => m.is_published).length;
	const drafts = total - published;
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-6 sm:grid-cols-3",
		children: [
			1,
			2,
			3
		].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "manuscript animate-pulse p-5 sm:p-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-24 rounded bg-ink-soft/20" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 h-8 w-16 rounded bg-ink-soft/20" })]
		}, i))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						icon: BookOpen,
						label: "Total majalis",
						value: total,
						accent: "bg-gold/20"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						icon: FileText,
						label: "Published",
						value: published,
						accent: "bg-emerald-500/20"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						icon: EyeOff,
						label: "Drafts",
						value: drafts,
						accent: "bg-amber-500/20"
					})
				]
			}),
			isError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "manuscript flex items-center gap-3 border-destructive/30 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "flex-1 text-sm text-destructive",
					children: "Could not load admin data. Try refreshing or sign out and sign in again."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => refetch(),
					className: "flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-xs text-ink hover:border-gold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { size: 14 }), "Retry"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/admin/majalis",
					className: "inline-flex items-center gap-2 rounded-md bg-ink px-5 py-2.5 text-sm text-parchment hover:bg-ink-soft",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { size: 16 }), "Manage majalis →"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => queryClient.invalidateQueries({ queryKey: ["admin"] }),
					className: "inline-flex items-center gap-1.5 rounded-md border border-border px-4 py-2.5 text-sm text-ink hover:border-gold hover:text-gold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { size: 14 }), "Refresh data"]
				})]
			})
		]
	});
}
//#endregion
export { Dashboard as component };
