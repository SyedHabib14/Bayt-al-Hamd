import { n as __toESM } from "./_runtime.mjs";
import { c as require_react, i as useQuery, o as useQueryClient, s as require_jsx_runtime, t as useMutation } from "./_libs/react+tanstack__react-query.mjs";
import { h as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { c as PenLine, g as ArrowLeft, h as BookOpen, o as RefreshCw, r as Trash2, s as Plus } from "./_libs/lucide-react.mjs";
import { c as saveMajlis, i as listAllMajalis, n as deleteMajlis, s as saveHadith, t as deleteHadith } from "./_ssr/admin.functions-Dzedo9E8.mjs";
import { a as supabase, t as formatDate } from "./_ssr/public-data-ZCIUHGBc.mjs";
import { t as Route } from "./_admin.admin.majalis._id.edit-BX_j_NjR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin.admin.majalis._id.edit-B6m5KCK1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useMajlisAndHadiths(id) {
	return useQuery({
		queryKey: [
			"admin",
			"majlis",
			id
		],
		queryFn: async () => {
			const { data: all } = await listAllMajalis().then((r) => ({ data: r }));
			const majlis = (all ?? []).find((m) => m.id === id) ?? null;
			const { data: hadiths } = await supabase.from("hadiths").select("*").eq("majlis_id", id).order("position").order("created_at");
			return {
				majlis,
				hadiths: hadiths ?? []
			};
		},
		staleTime: 15e3
	});
}
var HadithItem = (0, import_react.memo)(function HadithItem({ hadith, onEdit, onDelete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "manuscript p-5 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `inline-block rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider ${hadith.is_published ? "bg-emerald-500/10 text-emerald-600" : "bg-amber-500/10 text-amber-600"}`,
						children: hadith.is_published ? "Published" : "Draft"
					}), hadith.grade && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] uppercase tracking-wider text-ink-soft",
						children: hadith.grade
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => onEdit(hadith),
						className: "inline-flex items-center gap-1 rounded-md border border-border px-3 py-1.5 text-xs text-ink hover:border-gold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { size: 12 }), "Edit"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							if (confirm("Delete this hadith?")) onDelete(hadith.id);
						},
						className: "inline-flex items-center gap-1 rounded-md border border-destructive/40 px-3 py-1.5 text-xs text-destructive hover:bg-destructive/10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 12 }), "Delete"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "arabic-text mt-4 text-xl sm:text-2xl",
				dir: "rtl",
				children: hadith.arabic_text
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-serif text-base text-ink sm:text-lg",
				children: hadith.translation_en
			})
		]
	});
});
function EditMajlis() {
	const { id } = Route.useParams();
	const qc = useQueryClient();
	const { data, isLoading, refetch } = useMajlisAndHadiths(id);
	const [addingHadith, setAddingHadith] = (0, import_react.useState)(false);
	const [editingHadith, setEditingHadith] = (0, import_react.useState)(null);
	const invalidate = () => qc.invalidateQueries({ queryKey: [
		"admin",
		"majlis",
		id
	] });
	const delMajlis = useMutation({
		mutationFn: () => deleteMajlis({ data: { id } }),
		onSuccess: () => {
			window.location.href = "/admin/majalis";
		}
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-32 animate-pulse rounded bg-ink-soft/20" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "manuscript animate-pulse space-y-4 p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-24 rounded bg-ink-soft/20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-full rounded bg-ink-soft/20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-full rounded bg-ink-soft/20" })
			]
		})]
	});
	if (!data?.majlis) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
				size: 40,
				className: "text-ink-soft/40"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-display text-xl text-ink",
				children: "Majlis not found"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/admin/majalis",
				className: "mt-4 text-sm text-gold hover:underline",
				children: "← Back to all majalis"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 sm:space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/admin/majalis",
				className: "inline-flex items-center gap-1.5 text-xs uppercase tracking-[0.25em] text-ink-soft hover:text-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { size: 14 }), "All majalis"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MajlisEditForm, {
				majlis: data.majlis,
				onSaved: invalidate
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-display text-xl text-ink sm:text-2xl",
								children: [
									"Ḥadīths (",
									data.hadiths.length,
									")"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => refetch(),
								className: "flex h-7 w-7 items-center justify-center rounded-md border border-border text-ink-soft hover:border-gold hover:text-gold",
								title: "Refresh",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { size: 12 })
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								setAddingHadith((v) => !v);
								setEditingHadith(null);
							},
							className: "inline-flex items-center gap-1.5 rounded-md bg-ink px-3 py-2 text-xs text-parchment hover:bg-ink-soft sm:py-1.5",
							children: [addingHadith ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), addingHadith ? "Cancel" : "Add hadith"]
						})]
					}),
					addingHadith && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HadithForm, {
						majlisId: id,
						position: data.hadiths.length + 1,
						onDone: () => {
							setAddingHadith(false);
							invalidate();
						}
					}),
					editingHadith && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HadithForm, {
						majlisId: id,
						hadith: editingHadith,
						onDone: () => {
							setEditingHadith(null);
							invalidate();
						}
					}),
					data.hadiths.length === 0 && !addingHadith && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "manuscript mt-6 flex flex-col items-center py-12 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
								size: 36,
								className: "text-ink-soft/40"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-display text-lg text-ink",
								children: "No hadiths yet"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-ink-soft",
								children: "Add the first hadith to this majlis."
							})
						]
					}),
					data.hadiths.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 space-y-4",
						children: data.hadiths.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HadithItem, {
							hadith: h,
							onEdit: (hadith) => {
								setEditingHadith(hadith);
								setAddingHadith(false);
							},
							onDelete: (hadithId) => {
								deleteHadith({ data: { id: hadithId } }).then(() => invalidate());
							}
						}, h.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-destructive/30 pt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => {
						if (confirm("Delete this majlis and all its hadiths permanently?")) delMajlis.mutate();
					},
					className: "inline-flex items-center gap-1.5 rounded-md border border-destructive/40 px-4 py-2 text-sm text-destructive hover:bg-destructive/10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 14 }), "Delete majlis"]
				})
			})
		]
	});
}
function MajlisEditForm({ majlis, onSaved }) {
	const [title, setTitle] = (0, import_react.useState)(majlis.title);
	const [date, setDate] = (0, import_react.useState)(String(majlis.date).slice(0, 10));
	const [description, setDescription] = (0, import_react.useState)(majlis.description ?? "");
	const [isPublished, setIsPublished] = (0, import_react.useState)(majlis.is_published);
	const mut = useMutation({
		mutationFn: () => saveMajlis({ data: {
			id: majlis.id,
			title,
			date,
			description,
			is_published: isPublished
		} }),
		onSuccess: onSaved
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			mut.mutate();
		},
		className: "manuscript space-y-4 p-5 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] uppercase tracking-[0.25em] text-gold sm:text-xs",
				children: formatDate(String(majlis.date))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-[10px] uppercase tracking-[0.2em] text-ink-soft sm:text-xs",
					children: "Title"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: title,
					onChange: (e) => setTitle(e.target.value),
					className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2.5 text-sm text-ink sm:py-2"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-[10px] uppercase tracking-[0.2em] text-ink-soft sm:text-xs",
					children: "Date"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "date",
					value: date,
					onChange: (e) => setDate(e.target.value),
					className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2.5 text-sm text-ink sm:py-2"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "text-[10px] uppercase tracking-[0.2em] text-ink-soft sm:text-xs",
				children: "Description"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				value: description,
				onChange: (e) => setDescription(e.target.value),
				rows: 3,
				className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2.5 text-sm text-ink sm:py-2"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex cursor-pointer items-center gap-2 text-sm text-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: isPublished,
					onChange: (e) => setIsPublished(e.target.checked),
					className: "h-4 w-4"
				}), "Published"]
			}),
			mut.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: "Save failed. Please try again."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: mut.isPending,
				className: "rounded-md bg-ink px-4 py-2.5 text-sm text-parchment hover:bg-ink-soft disabled:opacity-60 sm:py-2",
				children: mut.isPending ? "Saving…" : "Save changes"
			})
		]
	});
}
function HadithForm({ majlisId, hadith, position, onDone }) {
	const [arabic, setArabic] = (0, import_react.useState)(hadith?.arabic_text ?? "");
	const [translation, setTranslation] = (0, import_react.useState)(hadith?.translation_en ?? "");
	const [grade, setGrade] = (0, import_react.useState)(hadith?.grade ?? "");
	const [notes, setNotes] = (0, import_react.useState)(hadith?.notes ?? "");
	const [isPublished, setIsPublished] = (0, import_react.useState)(hadith?.is_published ?? true);
	const mut = useMutation({
		mutationFn: () => saveHadith({ data: {
			id: hadith?.id,
			majlis_id: majlisId,
			arabic_text: arabic,
			translation_en: translation,
			grade: grade || null,
			notes: notes || null,
			is_published: isPublished,
			position: hadith?.position ?? position ?? 1
		} }),
		onSuccess: onDone
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			mut.mutate();
		},
		className: "manuscript mt-4 space-y-3 p-5 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "text-[10px] uppercase tracking-[0.2em] text-ink-soft sm:text-xs",
				children: "Arabic (with tashkeel)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				value: arabic,
				onChange: (e) => setArabic(e.target.value),
				rows: 3,
				dir: "rtl",
				className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2.5 font-arabic text-lg text-ink sm:text-xl sm:py-2"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "text-[10px] uppercase tracking-[0.2em] text-ink-soft sm:text-xs",
				children: "English translation"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				value: translation,
				onChange: (e) => setTranslation(e.target.value),
				rows: 3,
				className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2.5 font-serif text-sm text-ink sm:py-2"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-[10px] uppercase tracking-[0.2em] text-ink-soft sm:text-xs",
					children: "Grade"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: grade,
					onChange: (e) => setGrade(e.target.value),
					placeholder: "Ṣaḥīḥ, Ḥasan, Ḍaʿīf…",
					className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2.5 text-sm text-ink sm:py-2"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 flex cursor-pointer items-center gap-2 text-sm text-ink sm:mt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: isPublished,
						onChange: (e) => setIsPublished(e.target.checked),
						className: "h-4 w-4"
					}), "Published"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "text-[10px] uppercase tracking-[0.2em] text-ink-soft sm:text-xs",
				children: "Notes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				value: notes,
				onChange: (e) => setNotes(e.target.value),
				rows: 3,
				className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2.5 text-sm text-ink sm:py-2"
			})] }),
			mut.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: "Save failed. Please try again."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: mut.isPending,
				className: "rounded-md bg-ink px-4 py-2.5 text-sm text-parchment hover:bg-ink-soft disabled:opacity-60 sm:py-2",
				children: mut.isPending ? "Saving…" : "Save hadith"
			})
		]
	});
}
//#endregion
export { EditMajlis as component };
