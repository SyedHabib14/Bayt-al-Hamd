globalThis.__nitro_main__ = import.meta.url;
import { a as FastResponse, n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/about-Be9bpJOO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"554-GA4BjMXNRRKF/bOTOWnjpLaKJhc\"",
		"mtime": "2026-07-25T14:48:57.923Z",
		"size": 1364,
		"path": "../public/assets/about-Be9bpJOO.js"
	},
	"/assets/jsx-runtime-DGeXAQPT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3ab-mgnSm9dUpwL2+z7tKxJ2MsN0fOM\"",
		"mtime": "2026-07-25T14:48:57.924Z",
		"size": 939,
		"path": "../public/assets/jsx-runtime-DGeXAQPT.js"
	},
	"/assets/admin.functions-ra8udpeH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4d1-ulF8pwsLvl/4gXFfzchWG6CN9nc\"",
		"mtime": "2026-07-25T14:48:57.923Z",
		"size": 1233,
		"path": "../public/assets/admin.functions-ra8udpeH.js"
	},
	"/assets/book-open-BsWmZ7d6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10c-6LlcAHRP4ivbxShNcq6+FyVcP5k\"",
		"mtime": "2026-07-25T14:48:57.923Z",
		"size": 268,
		"path": "../public/assets/book-open-BsWmZ7d6.js"
	},
	"/assets/invariant-DByYf4Yy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d96-UflHk/0Jn8p+4GGVpx8kuqklxho\"",
		"mtime": "2026-07-25T14:48:57.924Z",
		"size": 7574,
		"path": "../public/assets/invariant-DByYf4Yy.js"
	},
	"/assets/link-CQ8mVV7D.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6639-Egoj+bbDdb6RxRWGwcl7otW8hKo\"",
		"mtime": "2026-07-25T14:48:57.924Z",
		"size": 26169,
		"path": "../public/assets/link-CQ8mVV7D.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-07-25T06:52:32.000Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/hadith._id-B9yEBJi-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6e0-9T2p7pn4AWE0IS8PBW+SZ074IdY\"",
		"mtime": "2026-07-25T14:48:57.923Z",
		"size": 1760,
		"path": "../public/assets/hadith._id-B9yEBJi-.js"
	},
	"/assets/unauthorized-XbaZf1CR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e2-Yp8dHedJGbTVhl/El6jcmi7EBU0\"",
		"mtime": "2026-07-25T14:48:57.925Z",
		"size": 738,
		"path": "../public/assets/unauthorized-XbaZf1CR.js"
	},
	"/assets/trash-2-Bu_YZz85.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a96-0gaZa0pMUfZXfGzF8FjFjaCLpoI\"",
		"mtime": "2026-07-25T14:48:57.925Z",
		"size": 2710,
		"path": "../public/assets/trash-2-Bu_YZz85.js"
	},
	"/assets/refresh-cw-B7adTU2j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"136-61COinx3T1PjXFtj5rMYxkJCEas\"",
		"mtime": "2026-07-25T14:48:57.924Z",
		"size": 310,
		"path": "../public/assets/refresh-cw-B7adTU2j.js"
	},
	"/assets/matchContext-DAMHwyzy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c7-ItK1ZEsCpQLOb3iQM85huFr3pPs\"",
		"mtime": "2026-07-25T14:48:57.924Z",
		"size": 199,
		"path": "../public/assets/matchContext-DAMHwyzy.js"
	},
	"/assets/useQuery-6hDF10C2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"60-2VVKamx/KDMauK70DUcCbH9hXLY\"",
		"mtime": "2026-07-25T14:48:57.925Z",
		"size": 96,
		"path": "../public/assets/useQuery-6hDF10C2.js"
	},
	"/assets/QueryClientProvider-lfxkrpOA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b17-YzKxB4bkmT7fscEAftPKaHxQdbg\"",
		"mtime": "2026-07-25T14:48:57.922Z",
		"size": 15127,
		"path": "../public/assets/QueryClientProvider-lfxkrpOA.js"
	},
	"/assets/useBaseQuery-DgLU89T3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2284-P+pkR6+0MHwKF5twsvInw/fnwNQ\"",
		"mtime": "2026-07-25T14:48:57.925Z",
		"size": 8836,
		"path": "../public/assets/useBaseQuery-DgLU89T3.js"
	},
	"/assets/pen-line-mrKqZWUs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10a-LmqyQVRMlitMvylicc6gHHboADk\"",
		"mtime": "2026-07-25T14:48:57.924Z",
		"size": 266,
		"path": "../public/assets/pen-line-mrKqZWUs.js"
	},
	"/assets/majlis._id-CuHBPAPC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae9-9Ehl5Gn1LgMFFnFfvK1rm8Yjql4\"",
		"mtime": "2026-07-25T14:48:57.924Z",
		"size": 2793,
		"path": "../public/assets/majlis._id-CuHBPAPC.js"
	},
	"/assets/majalis-Q1tYxcrt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"557-839WdDX7tEtejQLsNNVkV+bYIxQ\"",
		"mtime": "2026-07-25T14:48:57.924Z",
		"size": 1367,
		"path": "../public/assets/majalis-Q1tYxcrt.js"
	},
	"/assets/createServerFn-DMeXjG8L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1142-MTIYTm7QViumGOD3Nlob9FDcfPI\"",
		"mtime": "2026-07-25T14:48:57.923Z",
		"size": 4418,
		"path": "../public/assets/createServerFn-DMeXjG8L.js"
	},
	"/assets/login-BpvAz9Ka.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a82-xqtF92s3Br+qqh7c8uSTElw6QII\"",
		"mtime": "2026-07-25T14:48:57.924Z",
		"size": 2690,
		"path": "../public/assets/login-BpvAz9Ka.js"
	},
	"/assets/routes-ByqkR6Wa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a69-PIt94b9U8NsA3860FgsZ/8VkoNw\"",
		"mtime": "2026-07-25T14:48:57.925Z",
		"size": 2665,
		"path": "../public/assets/routes-ByqkR6Wa.js"
	},
	"/assets/redirect-DCb_aIiF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"271-AJO48VqfkUfrNYq6mvZqsvvYRKY\"",
		"mtime": "2026-07-25T14:48:57.924Z",
		"size": 625,
		"path": "../public/assets/redirect-DCb_aIiF.js"
	},
	"/assets/search-DQK3RxwS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"eb6-YUWxd9R8nGTJRtPM5DUUpMoxseI\"",
		"mtime": "2026-07-25T14:48:57.925Z",
		"size": 3766,
		"path": "../public/assets/search-DQK3RxwS.js"
	},
	"/assets/styles-COlDqkv3.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"150ae-5tUjryDB1BHGoGQsI12q+NClqyc\"",
		"mtime": "2026-07-25T14:48:57.926Z",
		"size": 86190,
		"path": "../public/assets/styles-COlDqkv3.css"
	},
	"/assets/index-vOZ25L2N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7e711-X7wUa4GWLy2VwWvQSprffSHZrUs\"",
		"mtime": "2026-07-25T14:48:57.922Z",
		"size": 517905,
		"path": "../public/assets/index-vOZ25L2N.js"
	},
	"/assets/useRouter-pVD1wXl8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d7-zlwx44msxSeX1kgFgq9bBAT7Oc0\"",
		"mtime": "2026-07-25T14:48:57.925Z",
		"size": 727,
		"path": "../public/assets/useRouter-pVD1wXl8.js"
	},
	"/assets/users-B7Zn4g0I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"127-ejNqiDB/Mc9pYy9ID6cLrUtaw3o\"",
		"mtime": "2026-07-25T14:48:57.926Z",
		"size": 295,
		"path": "../public/assets/users-B7Zn4g0I.js"
	},
	"/assets/useSuspenseQuery-bkgT6tHS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-UxBojI0X73SufY/UeFaXfG2+7E8\"",
		"mtime": "2026-07-25T14:48:57.926Z",
		"size": 174,
		"path": "../public/assets/useSuspenseQuery-bkgT6tHS.js"
	},
	"/assets/_admin-BRHHXcgW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"111e-h5fqTAQvQ7XF4P6TPviE8wFOX+4\"",
		"mtime": "2026-07-25T14:48:57.922Z",
		"size": 4382,
		"path": "../public/assets/_admin-BRHHXcgW.js"
	},
	"/assets/_admin.admin-CrTZyPto.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc5-7upeeGdftEix97ApeQ+N7WPyvz8\"",
		"mtime": "2026-07-25T14:48:57.922Z",
		"size": 3525,
		"path": "../public/assets/_admin.admin-CrTZyPto.js"
	},
	"/assets/_admin.admin.audit-Ve74vxxS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e30-doPJpD0scTrCZgolYWawQbcWDNY\"",
		"mtime": "2026-07-25T14:48:57.922Z",
		"size": 3632,
		"path": "../public/assets/_admin.admin.audit-Ve74vxxS.js"
	},
	"/assets/_admin.admin.majalis-OQgh0SQG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1895-atNGs0LCxjKaNX6RhQt0aVVh/2k\"",
		"mtime": "2026-07-25T14:48:57.923Z",
		"size": 6293,
		"path": "../public/assets/_admin.admin.majalis-OQgh0SQG.js"
	},
	"/assets/_admin.admin.majalis._id.edit-BYuvMsE8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2804-pFNZUor3a8czHcVuUTvLTl32GsU\"",
		"mtime": "2026-07-25T14:48:57.923Z",
		"size": 10244,
		"path": "../public/assets/_admin.admin.majalis._id.edit-BYuvMsE8.js"
	},
	"/assets/_admin.admin.users-DXx656RY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18be-/HUubjt01IIFAChznFqwEOIGJsE\"",
		"mtime": "2026-07-25T14:48:57.923Z",
		"size": 6334,
		"path": "../public/assets/_admin.admin.users-DXx656RY.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_GzVXNJ = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_GzVXNJ
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
