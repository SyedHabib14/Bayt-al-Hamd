import { n as __toESM } from "./_runtime.mjs";
import { c as require_react, i as useQuery, o as useQueryClient, s as require_jsx_runtime, t as useMutation } from "./_libs/react+tanstack__react-query.mjs";
import { s as useAuth, t as authHeaders } from "./_ssr/auth-store-BpIJ5qlL.mjs";
import { h as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { c as PenLine, h as BookOpen, o as RefreshCw, r as Trash2, s as Plus } from "./_libs/lucide-react.mjs";
import { c as saveMajlis, i as listAllMajalis, n as deleteMajlis } from "./_ssr/admin.functions-Dzedo9E8.mjs";
import { t as formatDate } from "./_ssr/public-data-ZCIUHGBc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin.admin.majalis-DQZsDy2l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MajlisRow = (0, import_react.memo)(function MajlisRow({ majlis, onDelete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex flex-col gap-3 border-b border-border py-4 last:border-b-0 sm:flex-row sm:items-center sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] uppercase tracking-[0.25em] text-gold sm:text-xs",
					children: formatDate(majlis.date)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-lg text-ink",
					children: majlis.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `mt-1 inline-block rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider ${majlis.is_published ? "bg-emerald-500/10 text-emerald-600" : "bg-amber-500/10 text-amber-600"}`,
					children: majlis.is_published ? "Published" : "Draft"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/admin/majalis/$id/edit",
				params: { id: majlis.id },
				className: "inline-flex items-center gap-1.5 rounded-md border border-border px-3 py-2 text-sm text-ink hover:border-gold hover:text-gold sm:py-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { size: 14 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden sm:inline",
					children: "Edit"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => {
					if (confirm("Delete this majlis and all its hadiths?")) onDelete(majlis.id);
				},
				className: "inline-flex items-center gap-1.5 rounded-md border border-destructive/40 px-3 py-2 text-sm text-destructive hover:bg-destructive/10 sm:py-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 14 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden sm:inline",
					children: "Delete"
				})]
			})]
		})]
	});
});
function AdminMajalis() {
	const { token } = useAuth();
	const qc = useQueryClient();
	const { data, isLoading, refetch } = useQuery({
		queryKey: ["admin", "majalis"],
		queryFn: () => listAllMajalis({ headers: authHeaders() }),
		enabled: Boolean(token),
		retry: false,
		staleTime: 3e4
	});
	const [creating, setCreating] = (0, import_react.useState)(false);
	const del = useMutation({
		mutationFn: (id) => deleteMajlis({
			data: { id },
			headers: authHeaders()
		}),
		onSuccess: () => qc.invalidateQueries({ queryKey: ["admin", "majalis"] }),
		onMutate: async (id) => {
			await qc.cancelQueries({ queryKey: ["admin", "majalis"] });
			const prev = qc.getQueryData(["admin", "majalis"]);
			qc.setQueryData(["admin", "majalis"], (old) => (old ?? []).filter((m) => m.id !== id));
			return { prev };
		},
		onError: (_err, _id, context) => {
			qc.setQueryData(["admin", "majalis"], context?.prev);
		}
	});
	const majalis = Array.isArray(data) ? data : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl text-ink sm:text-3xl",
					children: "Majalis"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => refetch(),
					className: "flex h-8 w-8 items-center justify-center rounded-md border border-border text-ink-soft hover:border-gold hover:text-gold",
					title: "Refresh",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { size: 14 })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => setCreating((v) => !v),
				className: "inline-flex items-center gap-1.5 rounded-md bg-ink px-4 py-2 text-sm text-parchment hover:bg-ink-soft",
				children: [creating ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 }), creating ? "Cancel" : "New majlis"]
			})]
		}),
		creating && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MajlisForm, { onDone: () => {
			setCreating(false);
			qc.invalidateQueries({ queryKey: ["admin", "majalis"] });
		} }),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 space-y-4",
			children: [
				1,
				2,
				3
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "animate-pulse border-b border-border pb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-24 rounded bg-ink-soft/20" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-2 h-5 w-48 rounded bg-ink-soft/20" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-2 h-4 w-16 rounded bg-ink-soft/20" })
				]
			}, i))
		}),
		!isLoading && majalis.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "manuscript mt-6 flex flex-col items-center py-16 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
					size: 40,
					className: "text-ink-soft/40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-display text-xl text-ink",
					children: "No majalis yet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-ink-soft",
					children: "Create your first majlis to get started."
				})
			]
		}),
		majalis.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 divide-y divide-border rounded-md border border-border bg-card px-4 sm:px-6",
			children: majalis.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MajlisRow, {
				majlis: m,
				onDelete: (id) => del.mutate(id)
			}, m.id))
		})
	] });
}
function MajlisForm({ onDone }) {
	const [title, setTitle] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [description, setDescription] = (0, import_react.useState)("");
	const [isPublished, setIsPublished] = (0, import_react.useState)(false);
	const mut = useMutation({
		mutationFn: () => saveMajlis({
			data: {
				title,
				date,
				description,
				is_published: isPublished
			},
			headers: authHeaders()
		}),
		onSuccess: () => onDone()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			mut.mutate();
		},
		className: "manuscript mt-4 space-y-4 p-5 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-[10px] uppercase tracking-[0.2em] text-ink-soft sm:text-xs",
					children: "Title"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: title,
					onChange: (e) => setTitle(e.target.value),
					required: true,
					className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2.5 text-sm text-ink sm:py-2"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-[10px] uppercase tracking-[0.2em] text-ink-soft sm:text-xs",
					children: "Date"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "date",
					value: date,
					onChange: (e) => setDate(e.target.value),
					required: true,
					className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2.5 text-sm text-ink sm:py-2"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "text-[10px] uppercase tracking-[0.2em] text-ink-soft sm:text-xs",
				children: "Description"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				value: description,
				onChange: (e) => setDescription(e.target.value),
				rows: 3,
				className: "mt-1 w-full rounded-md border border-border bg-card px-3 py-2.5 text-sm text-ink sm:py-2"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex cursor-pointer items-center gap-2 text-sm text-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: isPublished,
					onChange: (e) => setIsPublished(e.target.checked),
					className: "h-4 w-4"
				}), "Publish immediately"]
			}),
			mut.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: "Save failed. Please try again."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: mut.isPending,
				className: "rounded-md bg-ink px-4 py-2.5 text-sm text-parchment hover:bg-ink-soft disabled:opacity-60 sm:py-2",
				children: mut.isPending ? "Saving…" : "Save"
			})
		]
	});
}
//#endregion
export { AdminMajalis as component };
